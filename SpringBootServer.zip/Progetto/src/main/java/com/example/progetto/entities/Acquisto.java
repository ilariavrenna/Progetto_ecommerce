package com.example.progetto.entities;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import java.util.Date;
import java.util.Objects;
import java.util.Set;

@Getter
@Setter
@ToString
@EqualsAndHashCode
@Entity
@Table(name = "acquisto", schema = "progetto_psw")
public class Acquisto {

    @Id
    @Column(name = "numero_ordine", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int numeroOrdine;


    @Basic
    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "data_acquisto")
    private Date dataAcquisto;

    @Basic
    @Column(name = "prezzo")
    private double prezzo;

    @ManyToOne
    @JoinColumn(name = "utente")
    private Utente utente;


    @OneToMany(mappedBy = "acquisto", cascade = CascadeType.ALL)
    private Set<ProdottoAcquistato> listaProdottiAcquistati;

    @Override
    public int hashCode() {
        return Objects.hash(numeroOrdine);
    }
}
