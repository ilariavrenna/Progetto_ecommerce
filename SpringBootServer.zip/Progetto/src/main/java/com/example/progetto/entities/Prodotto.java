package com.example.progetto.entities;
import com.fasterxml.jackson.annotation.JsonIgnore;
import javax.persistence.*;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Set;

@Getter
@Setter
@ToString
@EqualsAndHashCode
@Entity
@Table(name = "prodotto", schema = "progetto_psw")
public class Prodotto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private int id;

    @Basic
    @Column(name = "nome", nullable = false, length = 70)
    private String nome;

    @Basic
    @Column(name = "codice", nullable = false, length = 70, unique = true)
    private String codice;

    @Basic
    @Column(name = "categoria", nullable = false, length = 70)
    private String categoria;

    @Basic
    @Column(name = "marca", nullable = false, length = 70)
    private String marca;

    @Basic
    @Column(name = "tipo", nullable = false, length = 70)
    private String tipo;

    @Basic
    @Column(name= "descrizione", nullable = false, length = 500)
    private String descrizione;

    @Basic
    @Column(name = "quantita", nullable = false)
    private int quantita;

    @Version
    @Column(name = "version", nullable = false)
    @JsonIgnore
    private long version;

    @Basic
    @Column(name = "prezzo", nullable = false)
    private double prezzo;

    @Column(name = "immagine", length = 100)
    private String immagine;

    @OneToMany(mappedBy = "prodotto", cascade = CascadeType.ALL)
    @JsonIgnore
    @ToString.Exclude
    private Set<ProdottoAcquistato> listaProdottiAcquistati;

    @OneToMany(mappedBy = "prodottoid", cascade = CascadeType.ALL)
    @ToString.Exclude
    @JsonIgnore
    private Set<ProdottoCarrello> listaProdottiCarello;




}
