package com.example.progetto.Service;

import com.example.progetto.Supporto.Exceptions.*;
import com.example.progetto.Repositories.RepositoryProdotto;
import com.example.progetto.Repositories.RepositoryProdottoInCarrello;
import com.example.progetto.Repositories.RepositoryUtente;
import com.example.progetto.entities.Prodotto;
import com.example.progetto.entities.ProdottoCarrello;
import com.example.progetto.entities.Utente;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class ServiceCarrello {

    @Autowired
    private RepositoryProdottoInCarrello carrelloRepository;
    @Autowired
    private RepositoryUtente utenteRepository;

    @Autowired
    private RepositoryProdotto prodottoRepository;



    @Transactional(readOnly = true)
    public List<ProdottoCarrello> getCarrello(String email) throws UserNotExistException {
        if(!utenteRepository.existsByEmail(email))
            throw new UserNotExistException();
        Utente u= utenteRepository.findByEmail(email);
        return carrelloRepository.findByUtente(u);
    }

    @Transactional
    public ProdottoCarrello addProdottoInCarello(Utente utente, String codiceProdotto) throws UserNotExistException, ProductNotExistException, QuantityProductUnavailableException {
        if(!utenteRepository.existsById(utente.getId())) {
            throw new UserNotExistException();
        }
        if(!prodottoRepository.existsByCodice(codiceProdotto)) {
            throw new ProductNotExistException();
        }
        ProdottoCarrello pc;
        Prodotto prodotto= prodottoRepository.findByCodice(codiceProdotto);
        if(carrelloRepository.existsByUtenteAndProdottoid(utente,prodotto)){
            pc= carrelloRepository.findByUtenteAndProdottoid(utente, prodotto);
            int quantita= pc.getQuantita()+1;
            if(quantita> prodotto.getQuantita())
                throw new QuantityProductUnavailableException();
            pc.setQuantita(quantita);
        }else{
            if( prodotto.getQuantita()<=0)
                throw new QuantityProductUnavailableException();
            pc= new ProdottoCarrello();
            pc.setUtente(utente);
            pc.setProdottoid(prodotto);
            pc.setQuantita(1);
            carrelloRepository.save(pc);
        }
        return pc;
    }

    @Transactional
   public List<ProdottoCarrello> incrementaProdottoInCarrello(String codiceProdotto, String emailUtente) throws ProductInShoppingCartNotFoundException, UserNotExistException, ProductNotExistException, OutOfStockException {
        if(!utenteRepository.existsByEmail(emailUtente)){
            throw new UserNotExistException();
        }
        if(!prodottoRepository.existsByCodice(codiceProdotto)){
            throw new ProductNotExistException();
        }
        Utente utente= utenteRepository.findByEmail(emailUtente);
        Prodotto prodotto= prodottoRepository.findByCodice(codiceProdotto);
        if(!carrelloRepository.existsByUtenteAndProdottoid(utente, prodotto))
            throw new ProductInShoppingCartNotFoundException();
        ProdottoCarrello pc= carrelloRepository.findByUtenteAndProdottoid(utente, prodotto);
        int quantita= pc.getQuantita()+1;
        if(quantita>prodotto.getQuantita())
             throw new OutOfStockException();
        else
            pc.setQuantita(quantita);
        return carrelloRepository.findByUtente(utente);
    }


    @Transactional
    public List<ProdottoCarrello> decrementaProdottoInCarrello(String codiceProdotto, String emailUtente) throws ProductInShoppingCartNotFoundException, UserNotExistException, ProductNotExistException {
        if(!utenteRepository.existsByEmail(emailUtente)){
            throw new UserNotExistException();
        }
        if(!prodottoRepository.existsByCodice(codiceProdotto)){
            throw new ProductNotExistException();
        }
        Utente utente= utenteRepository.findByEmail(emailUtente);
        Prodotto prodotto= prodottoRepository.findByCodice(codiceProdotto);
        if(!carrelloRepository.existsByUtenteAndProdottoid(utente, prodotto))
            throw new ProductInShoppingCartNotFoundException();
        ProdottoCarrello pc= carrelloRepository.findByUtenteAndProdottoid(utente, prodotto);
        int quantita= pc.getQuantita()-1;
        if(quantita<=0){
            //rimuovere dalla tabella
            carrelloRepository.delete(pc);
        }
        else {
            pc.setQuantita(quantita);
        }
        return carrelloRepository.findByUtente(utente);
    }

    @Transactional
    public List<ProdottoCarrello> eliminaProdottoInCarrello(String codiceProdotto, String emailUtente) throws UserNotExistException, ProductNotExistException, ProductInShoppingCartNotFoundException {
        if(!utenteRepository.existsByEmail(emailUtente)) {
            throw new UserNotExistException();
        }
        if(!prodottoRepository.existsByCodice(codiceProdotto)){
            throw new ProductNotExistException();
        }
        Utente utente= utenteRepository.findByEmail(emailUtente);
        Prodotto prodotto= prodottoRepository.findByCodice(codiceProdotto);
        if(!carrelloRepository.existsByUtenteAndProdottoid(utente, prodotto)){
            throw new ProductInShoppingCartNotFoundException();
        }
        ProdottoCarrello pc=carrelloRepository.findByUtenteAndProdottoid(utente,prodotto);
        carrelloRepository.delete(pc);
        return carrelloRepository.findByUtente(utente);
    }

    @Transactional
    public int getNumeroProdottiInCarrello(String emailUtente) throws UserNotExistException {
        if(!utenteRepository.existsByEmail(emailUtente)){
            throw new UserNotExistException();
        }
        Utente utente= utenteRepository.findByEmail(emailUtente);
        Integer numProdotti= carrelloRepository.countProduct(utente);
        if(numProdotti==null){
            return 0;
        }
        return numProdotti;
    }




}
