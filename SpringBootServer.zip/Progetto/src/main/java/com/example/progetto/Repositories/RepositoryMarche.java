package com.example.progetto.Repositories;

import com.example.progetto.entities.Acquisto;
import com.example.progetto.entities.Marche;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface RepositoryMarche extends JpaRepository<Marche, Integer> {

    List<Marche> findByMarcaContaining(String marca);

    boolean existsByMarca(String marca);
}
