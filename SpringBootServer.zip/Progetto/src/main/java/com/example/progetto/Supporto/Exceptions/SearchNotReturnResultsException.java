package com.example.progetto.Supporto.Exceptions;

public class SearchNotReturnResultsException extends Exception {

    public SearchNotReturnResultsException(){ }
}
