package com.example.progetto.Controllers;

import com.example.progetto.Supporto.Exceptions.*;
import com.example.progetto.Service.ServiceCarrello;
import com.example.progetto.Supporto.authentication.Utils;
import com.example.progetto.entities.ProdottoCarrello;
import com.example.progetto.entities.Utente;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/carrello")
public class ControllerCarrello {
    @Autowired
    ServiceCarrello serviceCarrello;

    @PreAuthorize("hasAuthority('buyer')")
    @GetMapping("/utente")
    public ResponseEntity getCarrello( ){
        try{
            List<ProdottoCarrello> carrello= serviceCarrello.getCarrello(Utils.getEmail());
            return  new ResponseEntity(carrello, HttpStatus.OK);
        }catch (UserNotExistException e){
            return new ResponseEntity("Utente non trovato", HttpStatus.BAD_REQUEST);
        }
    }


    @PreAuthorize("hasAuthority('buyer')")
    @PostMapping("/{idProdotto}")
    public ResponseEntity aggiungiAlCarrello(@PathVariable String idProdotto, @RequestBody @Valid Utente utente){
        try {
            ProdottoCarrello p=serviceCarrello.addProdottoInCarello(utente, idProdotto);
            return new ResponseEntity(p, HttpStatus.OK);
        } catch (ProductNotExistException | UserNotExistException | QuantityProductUnavailableException e){
            return new ResponseEntity("Errore. Qualcosa è andato storto", HttpStatus.BAD_REQUEST);
        }
    }

    @PreAuthorize("hasAuthority('buyer')")
    @PutMapping("/prodotto/{codiceProdotto}/incrementa")
    public ResponseEntity increaseQuantityProduct( @PathVariable String codiceProdotto) {
        try {
          List<ProdottoCarrello> pc=  serviceCarrello.incrementaProdottoInCarrello(codiceProdotto, Utils.getEmail());
          return new ResponseEntity(pc, HttpStatus.OK);
        }catch (ProductInShoppingCartNotFoundException e){
            return  new ResponseEntity("Prodotto non trovato nel carrello dell'utente.",HttpStatus.BAD_REQUEST);

        } catch (UserNotExistException  e) {
            return  new ResponseEntity("Utente non trovato", HttpStatus.BAD_REQUEST);

        } catch (ProductNotExistException e ){
            return  new ResponseEntity("Prodotto non trovato", HttpStatus.BAD_REQUEST);
        }catch (OutOfStockException e){
            return new ResponseEntity(HttpStatus.NOT_FOUND);
        }
    }

    @PreAuthorize("hasAuthority('buyer')")
    @PutMapping("/prodotto/{codiceProdotto}/decrementa")
    public ResponseEntity decreasesQuantityProduct( @PathVariable String codiceProdotto){
        try {
            List<ProdottoCarrello> pc=  serviceCarrello.decrementaProdottoInCarrello(codiceProdotto, Utils.getEmail());
            return new ResponseEntity(pc, HttpStatus.OK);
        }catch (ProductInShoppingCartNotFoundException e){
            return  new ResponseEntity("Prodotto non trovato nel carrello dell'utente.",HttpStatus.BAD_REQUEST);

        } catch (UserNotExistException  e) {
            return  new ResponseEntity("Utente non trovato", HttpStatus.BAD_REQUEST);

        } catch (ProductNotExistException e ){
            return  new ResponseEntity("Prodotto non trovato", HttpStatus.BAD_REQUEST);
        }
    }

    @PreAuthorize("hasAuthority('buyer')")
    @DeleteMapping("/prodotto/{codiceProdotto}/elimina")
    public ResponseEntity deleteAllQuantityProduct(@PathVariable String codiceProdotto){
        try{
            List<ProdottoCarrello> pc= serviceCarrello.eliminaProdottoInCarrello(codiceProdotto, Utils.getEmail());
            return new ResponseEntity(pc, HttpStatus.OK);
        }catch (ProductInShoppingCartNotFoundException e){
            return  new ResponseEntity("Prodotto non trovato nel carrello dell'utente.",HttpStatus.BAD_REQUEST);

        } catch (UserNotExistException  e) {
            return  new ResponseEntity("Utente non trovato", HttpStatus.BAD_REQUEST);

        } catch (ProductNotExistException e ){
            return  new ResponseEntity("Prodotto non trovato", HttpStatus.BAD_REQUEST);
        }
    }

    @PreAuthorize("hasAuthority('buyer')")
    @GetMapping("/quantita/prodotti")
    public ResponseEntity getQuantitaProdottiInCarrello(){
        try {
            int quantita= serviceCarrello.getNumeroProdottiInCarrello(Utils.getEmail());
            return new ResponseEntity(quantita, HttpStatus.OK);
        }catch (Exception e){
            return new ResponseEntity(HttpStatus.BAD_REQUEST);
        }
    }


}
