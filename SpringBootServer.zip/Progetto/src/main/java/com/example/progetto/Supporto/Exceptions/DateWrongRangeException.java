package com.example.progetto.Supporto.Exceptions;

public class DateWrongRangeException extends Exception{

    public DateWrongRangeException(){ }

}
