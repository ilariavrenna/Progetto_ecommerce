package com.example.progetto.Supporto;

import com.example.progetto.entities.Utente;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Data
public class ProductUpdateRequest {

    private String codeProduct;

    private int quantity;

    private double price;
}
