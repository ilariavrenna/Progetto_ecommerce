package com.example.progetto.Repositories;

import com.example.progetto.entities.Categorie;
import com.example.progetto.entities.Marche;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RepositoryCategorie extends JpaRepository<Categorie, Integer> {

    Categorie findByCategoriaLike(String categoria);
    boolean existsByCategoria(String categoria);
}
