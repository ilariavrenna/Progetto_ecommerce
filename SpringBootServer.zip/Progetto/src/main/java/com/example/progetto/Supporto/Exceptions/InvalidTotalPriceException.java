package com.example.progetto.Supporto.Exceptions;

public class InvalidTotalPriceException extends Exception{

    public InvalidTotalPriceException(){ }
}
