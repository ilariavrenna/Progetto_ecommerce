package com.example.progetto.entities;

import lombok.Data;
import javax.persistence.*;

@Entity
@Data
@Table(name = "marche", schema = "progetto_psw")
public class Marche {

    @Id
    @Column(name="id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Basic
    @Column(name= "marca" ,nullable = false, length = 50, unique = true)
    private String marca;
}
