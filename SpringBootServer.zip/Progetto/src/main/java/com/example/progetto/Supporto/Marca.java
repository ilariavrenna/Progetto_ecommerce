package com.example.progetto.Supporto;

public enum Marca {

    DIOR,
    PUPA,
    MAC,
    LANCOME,
    CHANEL,
    CLINIQUE,
    MAX_FACTOR,
    DEBORAH,
    VERSACE,
    DIEGO_DELLA_PALMA


}
