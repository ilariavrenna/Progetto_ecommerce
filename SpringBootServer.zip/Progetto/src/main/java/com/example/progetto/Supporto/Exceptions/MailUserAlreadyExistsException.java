package com.example.progetto.Supporto.Exceptions;

public class MailUserAlreadyExistsException extends Exception{

    public MailUserAlreadyExistsException(){

    }
}
