package com.example.progetto.Repositories;

import com.example.progetto.entities.Acquisto;
import com.example.progetto.entities.Utente;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface RepositoryAcquisto extends JpaRepository<Acquisto, Integer> {

    Page<Acquisto> findByUtente (Utente utente, Pageable pageable);

    Acquisto findByNumeroOrdine(int numeroOrdine);

    @Query("select a from Acquisto a where a.dataAcquisto >= ?1 and a.dataAcquisto <= ?2 and a.utente = ?3")
    Page<Acquisto> findByUtenteIntervalloData(Date dataI, Date dataF, Utente utente, Pageable pageable);

}
