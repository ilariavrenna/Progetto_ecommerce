package com.example.progetto.Service;

import com.example.progetto.Supporto.Exceptions.ProductAlreadyExistsException;
import com.example.progetto.Supporto.Exceptions.ProductNotExistException;
import com.example.progetto.Supporto.Exceptions.ProductNotFoundException;
import com.example.progetto.Repositories.RepositoryCategorie;
import com.example.progetto.Repositories.RepositoryMarche;
import com.example.progetto.Repositories.RepositoryProdotto;
import com.example.progetto.Repositories.RepositoryTipologieProdotti;
import com.example.progetto.Supporto.Exceptions.ProductPriceMismatchException;
import com.example.progetto.entities.Categorie;
import com.example.progetto.entities.Marche;
import com.example.progetto.entities.Prodotto;
import com.example.progetto.entities.TipologieProdotti;
import javassist.NotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

@Service
public class ServiceProdotto {

    @Autowired
    private RepositoryProdotto prodottoRepository;
    @Autowired
    private RepositoryMarche marcheRepository;
    @Autowired
    private RepositoryTipologieProdotti tipologieProdottiRepository;
    @Autowired
    private RepositoryCategorie categorieRepository;


    @Value("${path.image}")
    private String imageDirectory;

    @Transactional(readOnly = true)
    public List<Prodotto> mostraTuttiProdotti(){
        return prodottoRepository.findAll();
    }

    @Transactional(readOnly = true)
    public List<Prodotto> mostraTuttiProdotti(int pagNumero, int pagSize, String sortBy){
        Pageable pageable= PageRequest.of(pagNumero, pagSize, Sort.by(sortBy));
        Page<Prodotto> pagedResult= prodottoRepository.findAll(pageable);
        if(pagedResult.hasContent()){
            return pagedResult.getContent();
        }else{
            return new ArrayList<>();
        }

    }

    @Transactional(readOnly = true)
    public List<Prodotto> ricercaPerTipo(String type, int pageNumber, int pageSize, String sortBy){
      Pageable pageable= PageRequest.of(pageNumber, pageSize, Sort.by(sortBy));
      Page<Prodotto> pagedResult= prodottoRepository.findByTipo(type, pageable);
      if(pagedResult.hasContent())
          return pagedResult.getContent();
      return new ArrayList<>();
    }

    @Transactional(readOnly = true)
    public List<Prodotto> ricercaPerCategoria(String categoria, int pageNumber, int pageSize, String pageSort){
        Pageable pageable= PageRequest.of(pageNumber, pageSize, Sort.by(pageSort));
        Page<Prodotto> pagedResult= prodottoRepository.findByCategoria(categoria, pageable);
        return pagedResult.hasContent()? pagedResult.getContent() : new ArrayList<>();
    }

    @Transactional(readOnly = true)
    public List<Prodotto> ricercaAvanzata(String query, Double minPrice, Double maxPrice, HashSet<String> marche, int pageNumber, int pageSize, String sort)  {
        HashSet<String> listaM;
        if(marche==null){
            listaM= new HashSet<>();
        }else{
            listaM=marche;
        }
        String tipo = null;
        String categoria = null;
        Pageable pageable = PageRequest.of(pageNumber, pageSize, Sort.by(sort));
        if(query!=null) {
            StringTokenizer st = new StringTokenizer(query, " ");
            while (st.hasMoreTokens()) {
                String token = st.nextToken();
                if (tipo == null) {
                    TipologieProdotti tipologiaProdotto = tipologieProdottiRepository.findByTipoLike(token);
                    if (tipologiaProdotto != null) {
                        tipo = token;
                    }
                }
                List<Marche> listaMarche = marcheRepository.findByMarcaContaining(token);
                if (!listaMarche.isEmpty() && (listaM.isEmpty() || !listaM.containsAll(listaMarche))) {
                    for (Marche m : listaMarche)
                        listaM.add(m.getMarca());
                }
                if (categoria == null) {
                    Categorie c = categorieRepository.findByCategoriaLike(token);
                    if(c!=null){
                        categoria=token;
                    }
                }
            }
        }
        if(tipo==null&&categoria==null){
            return new ArrayList<>();
        }
        return  prodottoRepository.ricerca(tipo, categoria,minPrice, maxPrice, listaM , pageable).getContent();
    }

    @Transactional(readOnly = true)
    public List<Prodotto> ricercaPerQuery(String query, int pageNumber, int pageSize, String pageSort){
        String categoria= null, tipo = null;
        HashSet<String> marche= new HashSet<>();
        if(query!=null){
            StringTokenizer st = new StringTokenizer(query, " ");
            while (st.hasMoreTokens()) {
                String token = st.nextToken();
                if(tipo==null) {
                    TipologieProdotti tipologiaProdotto = tipologieProdottiRepository.findByTipoLike(token);
                    if (tipologiaProdotto != null) {
                        tipo = token;
                    }
                }
                List<Marche> listaMarche = marcheRepository.findByMarcaContaining(token);
                if (!listaMarche.isEmpty() && !marche.containsAll(listaMarche)) {
                    for (Marche m : listaMarche) {
                        marche.add(m.getMarca());
                    }
                }
                if (categoria == null) {
                    Categorie c = categorieRepository.findByCategoriaLike(token);
                    if (c != null) {
                        categoria = token;
                    }
                }
            }
        }

        if(tipo==null&&categoria==null&&marche.isEmpty()){
            return new ArrayList<>();
        }else {
            Page<Prodotto> pagedResult = prodottoRepository.ricercaPerQuery(tipo, categoria, marche.isEmpty() ? null : marche, PageRequest.of(pageNumber, pageSize, Sort.by(pageSort)));
            return pagedResult.hasContent() ? pagedResult.getContent() : new ArrayList<>();
        }
    }

    @Transactional(readOnly = true)
    public Prodotto getProdotto(String codiceProdotto) throws ProductNotFoundException {
        if(prodottoRepository.existsByCodice(codiceProdotto))
            throw new ProductNotFoundException();
       return prodottoRepository.findByCodice(codiceProdotto);
    }

    @Transactional
    public Prodotto updateProdotto(String codeProduct, double price, int quantity) throws Exception {
        if(!prodottoRepository.existsByCodice(codeProduct)){
            throw new ProductNotExistException();
        }
        Prodotto prodotto= prodottoRepository.findByCodice(codeProduct);
        int quantita= prodotto.getQuantita()+quantity;
        if(quantita<=0){
            throw new Exception();
        }
        prodotto.setQuantita(quantita);
        if(price<=0)
            throw new ProductPriceMismatchException();
        prodotto.setPrezzo(price);
        return prodotto;
    }

    @Transactional
    public Prodotto addProduct(Prodotto p) throws Exception {
        System.out.println(p);
        if(prodottoRepository.existsByCodice(p.getCodice())){
            throw new ProductAlreadyExistsException();
        }
        if(p.getPrezzo()<=0 || p.getQuantita()<=0){
            throw new Exception();
        }
        if(!isValidImageName(p.getImmagine())){
            throw new Exception();
        }
        if(!marcheRepository.existsByMarca(p.getMarca())){
            throw new Exception();
        }
        if(!categorieRepository.existsByCategoria(p.getCategoria())){
            throw new Exception();
        }
        if(!tipologieProdottiRepository.existsByTipo(p.getTipo())){
            throw new Exception();
        }
        return prodottoRepository.save(p);
    }



    public byte[] getImage(String imageName) throws IOException, NotFoundException {
        if(!isValidImageName(imageName)){
            throw  new NotFoundException("Not found image");
        }
        Path imagePath= Paths.get(imageDirectory, imageName);
        Resource resource = new FileSystemResource(imagePath.toFile());
        if(resource.exists() && resource.isReadable()){
            return resource.getInputStream().readAllBytes();
        }else{
            throw new NotFoundException("Not found image");
        }
    }

    private boolean isValidImageName(String imageName) {
        if (imageName == null || imageName.isEmpty()) {
            return false;
        }
        if (imageName.contains("..")) {
            return false;
        }
        String allowedChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_";
        for (char c : imageName.toCharArray()) {
            if (c!='.' && allowedChars.indexOf(c) == -1) {
                return false;
            }
        }
        String[] validExtensions = {".jpg", ".jpeg", ".png", ".gif"};
        String fileExtension = imageName.substring(imageName.lastIndexOf("."));
        for(String s : validExtensions) {
            if (fileExtension.equalsIgnoreCase(s)) {
                return true;
            }
        }
        return false;
    }








}
