package com.example.progetto.Supporto.Exceptions;

public class UserNotExistException extends Exception{

    public UserNotExistException(){ }
}
