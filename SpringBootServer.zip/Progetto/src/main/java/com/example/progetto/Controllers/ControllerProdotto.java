package com.example.progetto.Controllers;

import com.example.progetto.Supporto.Exceptions.*;
import com.example.progetto.Service.ServiceCarrello;
import com.example.progetto.Service.ServiceProdotto;
import com.example.progetto.Supporto.ProductUpdateRequest;
import com.example.progetto.entities.Prodotto;
import javassist.NotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;


import javax.validation.Valid;
import java.io.IOException;
import java.util.*;

@RestController
@RequestMapping("/product")
public class ControllerProdotto {
    @Autowired
    private ServiceProdotto serviceProdotto;
    @Autowired
    private ServiceCarrello serviceCarrello;


    @GetMapping("/all")
    public List<Prodotto> getAll(@RequestParam(value = "pageNumber", defaultValue = "0") int pageNumber,
                                 @RequestParam(value = "pageSize", defaultValue = "12") int pageSize,
                                 @RequestParam(value = "pageSort", defaultValue = "id") String pageSort) {
        return serviceProdotto.mostraTuttiProdotti(pageNumber, pageSize, pageSort);
    }

    @GetMapping("/category/{category}")
    public List<Prodotto> getCategory(@PathVariable String category, @RequestParam(value = "pageNumber", defaultValue = "0") int pageNumber,
                                      @RequestParam(value = "pageSize", defaultValue = "12") int pageSize, @RequestParam(value = "pageSort", defaultValue = "id") String pageSort){
        return serviceProdotto.ricercaPerCategoria(category, pageNumber, pageSize, pageSort);
    }

    @GetMapping("/type/{type}")
    public List<Prodotto> getTipo(@PathVariable String type, @RequestParam(value = "pageNumber", defaultValue = "0") int pageNumber,
                                  @RequestParam(value = "pageSize", defaultValue = "12") int pageSize, @RequestParam(value= "pageSort", defaultValue = "id") String pageSort) {
        return serviceProdotto.ricercaPerTipo(type,pageNumber, pageSize, pageSort);
    }

    @GetMapping("/search")
    public List<Prodotto> getProdotti(@RequestParam(value = "query", required = false) String query, @RequestParam(value = "pageNumber", defaultValue = "0") int pageNumber,
                                      @RequestParam(value = "pageSize", defaultValue = "12") int pageSize, @RequestParam(value = "pageSort", defaultValue = "id") String pageSort) {
        return  serviceProdotto.ricercaPerQuery(query, pageNumber, pageSize, pageSort);
    }

    @GetMapping("/searchAdvanced")
    public List<Prodotto> getRicercaAvanzata(@RequestParam(value = "query", required = false) String query,
                                      @RequestParam(value = "minPrice", defaultValue = "0") Double minPrice, @RequestParam(value = "maxPrice", defaultValue = "100") Double maxPrice,
                                      @RequestParam(value = "marca", required = false) HashSet<String> marca, @RequestParam(value = "pageNumber", defaultValue = "0") int pageNumber,
                                      @RequestParam(value = "pageSize", defaultValue = "12") int pageSize, @RequestParam(value = "pageSort", defaultValue = "id") String pageSort) {
        return  serviceProdotto.ricercaAvanzata(query, minPrice, maxPrice, marca, pageNumber, pageSize, pageSort);
    }


    @GetMapping("/{codice}")
    public ResponseEntity getProdotto(@PathVariable String codice) {

        try {
            Prodotto prodotto= serviceProdotto.getProdotto(codice);
            return new ResponseEntity(prodotto, HttpStatus.OK);
        }catch (ProductNotFoundException e){
            return new ResponseEntity("Pagina non trovata", HttpStatus.BAD_REQUEST);
        }
    }



    @GetMapping(value = "/image/{image}", produces = MediaType.IMAGE_PNG_VALUE)
    public ResponseEntity getImage(@PathVariable String image) {
       try {
           byte[] imageBytes = serviceProdotto.getImage(image);
           return new ResponseEntity(imageBytes, HttpStatus.OK);
       }catch (IOException | NotFoundException e){
           return new ResponseEntity(HttpStatus.NOT_FOUND);
       }
    }
    @PreAuthorize("hasAuthority('admin')")
    @PutMapping("/update")
    public ResponseEntity updateProduct(@RequestBody ProductUpdateRequest p){
        try{
            return new ResponseEntity(serviceProdotto.updateProdotto(p.getCodeProduct(), p.getPrice(), p.getQuantity()), HttpStatus.OK);
        }catch (Exception e){
            return new ResponseEntity(HttpStatus.BAD_REQUEST);
        }
    }

    @PreAuthorize("hasAuthority('admin')")
    @PostMapping("/add")
    public ResponseEntity addProduct(@RequestBody @Valid Prodotto prodotto ){
        try{
            return new ResponseEntity(serviceProdotto.addProduct(prodotto), HttpStatus.OK);
        }catch (Exception e){
            return new ResponseEntity(HttpStatus.BAD_REQUEST);
        }
    }




}