package com.example.progetto.entities;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name= "categorie", schema = "progetto_pws")
public class Categorie {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private int id;

    @Basic
    @Column(name = "categoria", nullable = false, unique = true, length = 50)
    private String categoria;
}
