package com.example.progetto.Service;

import com.example.progetto.Repositories.RepositoryProdotto;
import com.example.progetto.Repositories.RepositoryProdottoInCarrello;
import com.example.progetto.Repositories.RepositoryUtente;
import com.example.progetto.Supporto.Exceptions.MailUserAlreadyExistsException;
import com.example.progetto.Supporto.Exceptions.ProductNotExistException;
import com.example.progetto.Supporto.Exceptions.UserNotExistException;
import com.example.progetto.Supporto.Exceptions.UserRegistrationFailedException;
import com.example.progetto.entities.Prodotto;
import com.example.progetto.entities.ProdottoCarrello;
import com.example.progetto.entities.Utente;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.KeycloakBuilder;
import org.keycloak.representations.idm.CredentialRepresentation;
import org.keycloak.representations.idm.UserRepresentation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import javax.ws.rs.core.Request;
import javax.ws.rs.core.Response;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ServiceAccount {

    @Value("${keycloak.auth-server-url-register}")
    private String KEYCLOAK_SERVER_URL_REGISTER;

    @Value("${keycloak.client-id}")
    private String CLIENT_ID;


    @Value("${keycloak.auth-server-url-token}")
    private String KEYCLOAK_SERVER_URL_TOKEN;

    @Value("${keycloak.password}")
    private String PASSWORD;


    @Autowired
    private RepositoryUtente utenteRepository;

    @Autowired
    private RepositoryProdottoInCarrello repositoryCarrello;

    @Autowired
    private RepositoryProdotto prodottoRepository;



    @Transactional
    public Utente setNumeroTelefono(Utente u) throws UserNotExistException {
        if(!utenteRepository.existsById(u.getId()))
            throw new UserNotExistException();
        Utente utente= utenteRepository.findById(u.getId());
        utente.setTelefono(u.getTelefono());
        return utente;
    }


    @Transactional
    public Utente setAddress(Utente u) throws UserNotExistException{
        if(!utenteRepository.existsById(u.getId()))
            throw new UserNotExistException();
        Utente utente= utenteRepository.findById(u.getId());
        utente.setIndirizzo(u.getIndirizzo());
        return utente;
    }

    public Utente getUserInfo(String email) throws UserNotExistException {
        if(!utenteRepository.existsByEmail(email)){
            throw new UserNotExistException();
        }
        return utenteRepository.findByEmail(email);
    }

    @Transactional
    public Utente login(String email, List<ProdottoCarrello> carrello) throws UserNotExistException, ProductNotExistException {
        if(!utenteRepository.existsByEmail(email)){
            throw new UserNotExistException();
        }
        Utente utente= utenteRepository.findByEmail(email);
        for(ProdottoCarrello pc : carrello){
            if(!prodottoRepository.existsByCodice(pc.getProdottoid().getCodice())){
                throw new ProductNotExistException();
            }
            Prodotto prodotto= prodottoRepository.findByCodice(pc.getProdottoid().getCodice());
            if(repositoryCarrello.existsByUtenteAndProdottoid(utente, prodotto)){
                ProdottoCarrello prodottoCarrello= repositoryCarrello.findByUtenteAndProdottoid(utente, prodotto);
                int quantita= prodottoCarrello.getQuantita()+pc.getQuantita();
                if(quantita> prodotto.getQuantita()){
                    prodottoCarrello.setQuantita(prodotto.getQuantita());
                }else {
                    prodottoCarrello.setQuantita(quantita);
                }
            }else {
                if(pc.getQuantita()>prodotto.getQuantita()){
                    pc.setQuantita(prodotto.getQuantita());
                }
                pc.setUtente(utente);
                repositoryCarrello.save(pc);
            }
        }
        return utente;
    }



    @Transactional
    public Utente registrazioneUtente(Utente u, String password) throws MailUserAlreadyExistsException, UserRegistrationFailedException, JsonProcessingException {
        if(utenteRepository.existsByEmail(u.getEmail())){
            throw  new MailUserAlreadyExistsException();
        }

        //Richiedo il token di accesso amministratore
        RestTemplate restTemplate= new RestTemplate();

        //headers
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.valueOf(MediaType.APPLICATION_FORM_URLENCODED_VALUE));

        //corpo della richiesta
        MultiValueMap<String, String> body = new LinkedMultiValueMap<>();
        body.add("grant_type", "password");
        body.add("username", "admin");
        body.add("password", PASSWORD);
        body.add("client_id", CLIENT_ID);


        HttpEntity<MultiValueMap<String, String>> requestEntity= new HttpEntity<>(body, headers);


        ResponseEntity<String> responseToken = restTemplate.exchange(
                KEYCLOAK_SERVER_URL_TOKEN,
                HttpMethod.POST,
                requestEntity,
                String.class
        );

        if(responseToken.getStatusCode()== HttpStatus.OK){
            //recupero il token
            ObjectMapper objectMapper= new ObjectMapper();

            Map<String, String> response= objectMapper.readValue(responseToken.getBody(), Map.class);
            String token= response.get("access_token");

            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.setBearerAuth(token);

            UserRepresentation user = new UserRepresentation();
            user.setFirstName(u.getNome());
            user.setLastName(u.getCognome());
            user.setEmail(u.getEmail());
            user.setEnabled(true);
            user.setEmailVerified(true);

            CredentialRepresentation passwordCred= new CredentialRepresentation();
            passwordCred.setValue(password);
            passwordCred.setTemporary(false);
            passwordCred.setType(CredentialRepresentation.PASSWORD);
            user.setCredentials(Arrays.asList(passwordCred));

            user.setGroups(Arrays.asList("clienti"));

            String bodyRegistration= objectMapper.writeValueAsString(user);

            HttpEntity<String> requestRegistration= new HttpEntity<>(bodyRegistration, headers);

            //Registro l'utente su keycloak
            ResponseEntity<String> responseRegister = restTemplate.exchange(
                    KEYCLOAK_SERVER_URL_REGISTER,
                    HttpMethod.POST,
                    requestRegistration,
                    String.class
            );
            if(responseRegister.getStatusCode() == HttpStatus.CREATED){
                return utenteRepository.save(u);
            }else{
                throw new UserRegistrationFailedException();
            }
        }else{
            throw new UserRegistrationFailedException();
        }
    }









}
