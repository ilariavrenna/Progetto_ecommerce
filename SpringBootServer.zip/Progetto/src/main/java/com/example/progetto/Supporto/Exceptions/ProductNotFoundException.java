package com.example.progetto.Supporto.Exceptions;

public class ProductNotFoundException extends Exception{

    public ProductNotFoundException(){ }
}
