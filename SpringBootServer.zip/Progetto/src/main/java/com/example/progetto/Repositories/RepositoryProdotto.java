package com.example.progetto.Repositories;

import com.example.progetto.entities.Marche;
import com.example.progetto.entities.Prodotto;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Repository
public interface RepositoryProdotto extends JpaRepository<Prodotto, Integer>  {

    Prodotto findById(int id);
    Prodotto findByCodice(String codice);
    boolean existsByCodice(String codice);

    Page<Prodotto> findByCategoria(String categoria, Pageable pageable);
    Page<Prodotto> findByTipo(String type, Pageable pageable);



    @Query("SELECT p FROM Prodotto p " +
            "WHERE (:tipo IS NULL OR p.tipo LIKE :tipo) " +
            "AND (:categoria IS NULL OR p.categoria LIKE :categoria) " +
            "AND (:prezzoMin IS NULL OR p.prezzo >= :prezzoMin) " +
            "AND (:prezzoMax IS NULL OR p.prezzo <= :prezzoMax) " +
            "AND ( COALESCE(:marche, null) IS NULL OR p.marca IN (:marche) )"
    )
    Page<Prodotto> ricerca(@Param("tipo") String tipo,
                           @Param("categoria") String categoria,
                           @Param("prezzoMin") Double prezzoMin,
                           @Param("prezzoMax") Double prezzoMax,
                           @Param("marche") HashSet<String> marche,
                           Pageable pageable
    );

    @Query("select p "+
            "from Prodotto p "+
            "where (:tipo IS NULL OR p.tipo LIKE :tipo) AND"+
            "      (:categoria IS NULL OR p.categoria LIKE :categoria) AND"+
            "      (COALESCE(:marche, null) IS NULL OR p.marca IN (:marche))"
    )
    Page<Prodotto> ricercaPerQuery(@Param("tipo") String tipo, @Param("categoria") String categoria, @Param("marche") HashSet<String> marche, Pageable pageable);



}
