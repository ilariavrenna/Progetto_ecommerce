package com.example.progetto.Supporto.Exceptions;

public class ProductAlreadyExistsException extends Exception{

    public ProductAlreadyExistsException(){}
}
