package com.example.progetto.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.ToString;

import javax.persistence.*;
import java.util.Objects;

@Data
@Entity
@Table(name="prodotto_acquistato", schema= "progetto_psw")
public class ProdottoAcquistato {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id", nullable = false)
    private int id;

    @Basic
    @Column(name= "quantita")
    private int quantita;

    @Basic
    @Column(name= "prezzo")
    private double prezzo;

    @ManyToOne
    @JoinColumn(name="id_prodotto")
    private Prodotto prodotto;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "numero_ordine" )
    @ToString.Exclude
    private Acquisto acquisto;

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }



}
