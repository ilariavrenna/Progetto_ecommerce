package com.example.progetto.Supporto.Exceptions;

public class ProductNotExistException extends Exception{

    public ProductNotExistException(){

    }
}
