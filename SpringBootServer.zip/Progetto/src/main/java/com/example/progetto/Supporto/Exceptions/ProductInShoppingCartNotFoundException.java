package com.example.progetto.Supporto.Exceptions;

public class ProductInShoppingCartNotFoundException extends Exception{

    public ProductInShoppingCartNotFoundException() { }
}
