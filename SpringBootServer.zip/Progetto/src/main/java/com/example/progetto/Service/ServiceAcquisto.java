package com.example.progetto.Service;


import com.example.progetto.Repositories.*;
import com.example.progetto.Supporto.Exceptions.*;
import com.example.progetto.entities.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class ServiceAcquisto {

    @Autowired
    private RepositoryAcquisto acquistoRepository;

    @Autowired
    private RepositoryProdottoInAcquisto prodottoInAcquistoRepository;
    @Autowired
    private RepositoryUtente  utenteRepository;

    @Autowired
    private RepositoryProdotto prodottoRepository;

    @Autowired
    private RepositoryProdottoInCarrello carrelloRepository;

    @Autowired
    EntityManager entityManager;


    @Transactional(readOnly = true)
    public List<Acquisto> getAcquistiByUtente(String email, int pageNumber, int pageSize, String pageSort) throws UserNotExistException {
        if(!utenteRepository.existsByEmail(email))
            throw new UserNotExistException();
        Utente u= utenteRepository.findByEmail(email);
        Pageable pageable= PageRequest.of(pageNumber, pageSize, Sort.by(Sort.Direction.DESC, pageSort));
        Page<Acquisto> pagedResult= acquistoRepository.findByUtente(u, pageable);
        if(pagedResult.hasContent()){
            return pagedResult.getContent();
        }
        return new ArrayList<>();
    }

    @Transactional(readOnly = true)
    public List<Acquisto> acquistiIntervalloData(Date dataI, Date dataF, Utente u, int pageNumber, int pageSize, String pageSort) throws UserNotExistException, DateWrongRangeException {
        if(!utenteRepository.existsById(u.getId()))
            throw new UserNotExistException();
        if(dataI.compareTo(dataF) > 0 )
            throw new DateWrongRangeException();
        Pageable pageable= PageRequest.of(pageNumber, pageSize, Sort.by(pageSort));
        return acquistoRepository.findByUtenteIntervalloData(dataI, dataF, u, pageable).getContent();
    }

    @Transactional
    public Acquisto aggiungiAcquisto(Acquisto a) throws UserNotExistException, QuantityProductUnavailableException, ProductNotExistException, ProductPriceMismatchException, InvalidTotalPriceException {
        if(!utenteRepository.existsById(a.getUtente().getId())) {
            throw new UserNotExistException();
        }
        double totale=0;
        for(ProdottoAcquistato pa : a.getListaProdottiAcquistati()){
            pa.setAcquisto(a);
            Prodotto prodotto= pa.getProdotto();
            if(!prodottoRepository.existsByCodice(prodotto.getCodice())){
                throw new ProductNotExistException();
            }
            Prodotto p= prodottoRepository.findByCodice(prodotto.getCodice());
            if(p.getPrezzo()!=prodotto.getPrezzo()){
                throw new ProductPriceMismatchException();
            }
            totale+=p.getPrezzo()*pa.getQuantita();
            int quantity= p.getQuantita()-pa.getQuantita();
            if(quantity<0){
                throw new QuantityProductUnavailableException();
            }
            p.setQuantita(quantity);
        }
        if(totale!=a.getPrezzo()){
            throw new InvalidTotalPriceException();
        }
        Acquisto acquisto= acquistoRepository.save(a);
        carrelloRepository.deleteAllByUtente(acquisto.getUtente());
        return acquisto;
    }

    @Transactional
    public List<ProdottoCarrello> getQuantitaProdotto(Utente utente)  {
        List<ProdottoCarrello> carrelloUtente= carrelloRepository.findByUtente(utente);
        List<ProdottoCarrello> prodottiDarimuovere= new ArrayList<>();
        for(ProdottoCarrello pc : carrelloUtente){
            int quantita= pc.getProdottoid().getQuantita()-pc.getQuantita();
            if(pc.getProdottoid().getQuantita()==0){
                prodottiDarimuovere.add(pc);
            }else if(quantita<0) {
                pc.setQuantita(pc.getProdottoid().getQuantita());
            }
        }
        carrelloRepository.deleteAll(prodottiDarimuovere);
        return carrelloRepository.findByUtente(utente);
    }







}
