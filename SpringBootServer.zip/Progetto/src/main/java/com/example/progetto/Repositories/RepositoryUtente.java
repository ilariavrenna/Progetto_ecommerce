package com.example.progetto.Repositories;

import com.example.progetto.entities.Utente;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface RepositoryUtente extends JpaRepository<Utente, Integer> {

    Utente findById(int id);
    List<Utente> findByNome(String nome);
    List<Utente> findByCognome(String name);
    List<Utente> findByNomeAndCognome(String nome, String cognome);
    Utente findByEmail(String email);
    boolean existsByEmail(String email);
    boolean existsById(Utente u);

}
