package com.example.progetto.Supporto.Exceptions;

public class QuantityProductUnavailableException extends  Exception{

    public  QuantityProductUnavailableException(){ }
}
