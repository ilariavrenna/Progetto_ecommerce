package com.example.progetto.Supporto;

import com.example.progetto.entities.Utente;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Data
public class RegistrationRequest {

    @Valid
    private Utente utente;

    @NotBlank(message = "Il campo password non può essere vuoto.")
    @Size(min = 8)
    private String password;


}
