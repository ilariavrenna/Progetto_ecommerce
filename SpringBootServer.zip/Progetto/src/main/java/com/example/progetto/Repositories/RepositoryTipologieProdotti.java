package com.example.progetto.Repositories;

import com.example.progetto.entities.TipologieProdotti;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface RepositoryTipologieProdotti extends JpaRepository<TipologieProdotti, Integer> {

    TipologieProdotti findByTipoLike (String tipo);
    boolean existsByTipo(String tipo);
}
