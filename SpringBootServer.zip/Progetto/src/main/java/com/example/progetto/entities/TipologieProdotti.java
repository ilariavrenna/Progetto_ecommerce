package com.example.progetto.entities;


import javax.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name="tipologie_prodotti", schema= "progetto_psw")
public class TipologieProdotti {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name= "id", nullable = false)
    private int id;


    @Basic
    @Column(name = "tipo", nullable = false, length = 50, unique = true)
    private String tipo;
}
