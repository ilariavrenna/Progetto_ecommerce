package com.example.progetto.Supporto;

public enum TipologiaProdotto {
    ROSSETTO,
    GLOSS,
    MASCARA,
    PROFUMO,
    MATITA,
    CIPRIA,
    CORRETTORE,
    OMBRETTO,
    BLUSH,
    BRONZER,
    ILLUMINANTE,
    EYELINER,
    FONDOTINTA,
    ACCESSORI
}
