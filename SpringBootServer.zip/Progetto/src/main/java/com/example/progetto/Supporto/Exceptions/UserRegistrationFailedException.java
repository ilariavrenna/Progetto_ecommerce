package com.example.progetto.Supporto.Exceptions;

public class UserRegistrationFailedException extends Exception {

    public UserRegistrationFailedException(){ }
}
