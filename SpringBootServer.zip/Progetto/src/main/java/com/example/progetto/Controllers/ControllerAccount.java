package com.example.progetto.Controllers;

import com.example.progetto.Supporto.Exceptions.MailUserAlreadyExistsException;
import com.example.progetto.Service.ServiceAccount;
import com.example.progetto.Supporto.Exceptions.ProductNotExistException;
import com.example.progetto.Supporto.Exceptions.UserNotExistException;
import com.example.progetto.Supporto.Exceptions.UserRegistrationFailedException;
import com.example.progetto.Supporto.RegistrationRequest;
import com.example.progetto.Supporto.authentication.Utils;
import com.example.progetto.entities.ProdottoCarrello;
import com.example.progetto.entities.Utente;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;


@RestController
@RequestMapping("/user")
public class ControllerAccount {

    @Autowired
    private ServiceAccount serviceAccount;



    @PostMapping("/registration")
    public ResponseEntity create(@RequestBody @Valid RegistrationRequest request ){
        try{
            Utente u= serviceAccount.registrazioneUtente(request.getUtente(), request.getPassword());
            return new ResponseEntity(u, HttpStatus.CREATED);
        }catch (MailUserAlreadyExistsException e){
            return new ResponseEntity<>("Registrazione fallita. Esiste già un account con questo indirizzo email. Utilizza un indirizzo email diverso o accedi con il tuo account esistente", HttpStatus.CONFLICT);
        }catch (UserRegistrationFailedException | JsonProcessingException e){
            return new ResponseEntity<>("La registrazione dell'utente non è riuscita. Controlla le tue informazioni e riprova", HttpStatus.BAD_REQUEST);
        }
    }


    @PreAuthorize("hasAuthority('buyer')")
    @PostMapping("/login")
    public ResponseEntity login(@RequestBody List<ProdottoCarrello> carrello)  {
        try {
            return new  ResponseEntity(serviceAccount.login(Utils.getEmail(), carrello), HttpStatus.OK);
        } catch(UserNotExistException | ProductNotExistException e) {
            return new ResponseEntity("Accesso non riuscito. L'indirizzo email che hai fornito non esiste nel nostro sistema.", HttpStatus.BAD_REQUEST);
        }
    }

    @PreAuthorize("hasAuthority('buyer')")
    @PutMapping("/address")
    public  ResponseEntity updateAdress(@RequestBody @Valid Utente utente){
        try{
            return new ResponseEntity(serviceAccount.setAddress(utente), HttpStatus.OK);
        }catch (UserNotExistException e){
            return new ResponseEntity(HttpStatus.BAD_REQUEST);
        }
    }


    @PreAuthorize("hasAuthority('buyer')")
    @PutMapping("/phone")
    public  ResponseEntity updatePhone(@RequestBody @Valid Utente utente){
        try{
            return new ResponseEntity(serviceAccount.setNumeroTelefono(utente), HttpStatus.OK);
        }catch (UserNotExistException e){
            return new ResponseEntity(HttpStatus.BAD_REQUEST);
        }
    }

    @PreAuthorize("hasAuthority('buyer')")
    @GetMapping("/info")
    public ResponseEntity userInfo(){
        try{
            return new ResponseEntity(serviceAccount.getUserInfo(Utils.getEmail()), HttpStatus.OK);
        }catch (UserNotExistException e){
            return new ResponseEntity(HttpStatus.BAD_REQUEST);
        }
    }



}
