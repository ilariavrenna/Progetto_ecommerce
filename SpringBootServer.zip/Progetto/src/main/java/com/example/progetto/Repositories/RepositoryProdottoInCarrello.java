package com.example.progetto.Repositories;

import com.example.progetto.entities.Prodotto;
import com.example.progetto.entities.ProdottoCarrello;
import com.example.progetto.entities.Utente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RepositoryProdottoInCarrello extends JpaRepository<ProdottoCarrello, Integer> {

    List<ProdottoCarrello> findByUtente(Utente utente);

    ProdottoCarrello findByUtenteAndProdottoid(Utente utente, Prodotto prodotto);

    boolean existsByUtenteAndProdottoid(Utente u, Prodotto p);


    @Query("SELECT SUM(p.quantita) FROM  ProdottoCarrello  p WHERE p.utente = ?1 ")
    Integer countProduct(Utente u);


    void deleteAllByUtente(Utente u);
}
