package com.example.progetto.entities;

import javax.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name="prodotto_in_carrello", schema = "progetto_psw")
public class ProdottoCarrello {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id", nullable = false)
    private int id;

    @Basic
    @Column(name="quantita")
    private int quantita;

    @ManyToOne
    @JoinColumn(name= "id_prodotto")
    private Prodotto prodottoid;

    @ManyToOne
    @JoinColumn(name="id_utente")
    private Utente utente;
}

