package com.example.progetto.Supporto.Exceptions;

public class OutOfStockException extends Exception{

    public OutOfStockException(){

    }
}
