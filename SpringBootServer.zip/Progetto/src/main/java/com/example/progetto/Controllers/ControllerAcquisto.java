package com.example.progetto.Controllers;

import com.example.progetto.Service.ServiceAcquisto;
import com.example.progetto.Supporto.Exceptions.*;
import com.example.progetto.Supporto.authentication.Utils;
import com.example.progetto.entities.Acquisto;
import com.example.progetto.entities.Utente;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/ordine")
public class ControllerAcquisto {

    @Autowired
    private ServiceAcquisto acquistoService;




    @PreAuthorize("hasAuthority('buyer')")
    @GetMapping("/all")
    public ResponseEntity getAllAcquisti(@RequestParam(value = "pageNumber", defaultValue = "0") int pageNumber,
                                         @RequestParam(value = "pageSize", defaultValue = "6") int pageSize,
                                         @RequestParam(value = "pageSort", defaultValue = "dataAcquisto") String pageSort){
        try {
            List<Acquisto> ordini= acquistoService.getAcquistiByUtente(Utils.getEmail(), pageNumber, pageSize, pageSort);
            return new ResponseEntity(ordini, HttpStatus.OK);
        }catch (UserNotExistException e){
            return new ResponseEntity("Utente non trovato.", HttpStatus.BAD_REQUEST);
        }
    }


    @PreAuthorize("hasAuthority('buyer')")
    @GetMapping("/{user}/{startDate}/{endDate}")
    public ResponseEntity getAcquistiIntervallo(@PathVariable("user") @Valid Utente utente, @PathVariable("startDate") @DateTimeFormat(pattern = "dd-MM-yyyy") Date start,
                                                @PathVariable("endDate") @DateTimeFormat(pattern = "dd-MM-yyyy") Date end,
                                                @RequestParam(value = "pageNumber", defaultValue = "0") int pageNumber,
                                                @RequestParam(value = "pageSize", defaultValue = "6") int pageSize,
                                                @RequestParam(value = "pageSort", defaultValue = "id") String pageSort){
        try {
            System.out.println("SON QUA "+
            start.toString()+ "  "+
                    end.toString()
                    );
            List<Acquisto> ordini= acquistoService.acquistiIntervalloData(start, end, utente, pageNumber, pageSize, pageSort);
            return new ResponseEntity(ordini, HttpStatus.OK);
        }catch (UserNotExistException e){
            return new ResponseEntity("Utente non trovato", HttpStatus.BAD_REQUEST);
        }catch (DateWrongRangeException e){
            return new ResponseEntity("La data di inzio deve essere antecedente alla data di fine", HttpStatus.BAD_REQUEST);
        }
    }

    @PreAuthorize("hasAuthority('buyer')")
    @PostMapping("/checkout")
    public ResponseEntity creaAcquisto(@RequestBody @Valid Acquisto acquisto) {
        try {
            return new ResponseEntity(acquistoService.aggiungiAcquisto(acquisto), HttpStatus.OK);
        }catch (UserNotExistException | ProductNotExistException | InvalidTotalPriceException e){
            return new ResponseEntity(HttpStatus.BAD_REQUEST);
        }catch (ProductPriceMismatchException e) {
            return new ResponseEntity(acquistoService.getQuantitaProdotto(acquisto.getUtente()), HttpStatus.CONFLICT);
        }catch (QuantityProductUnavailableException e){
            return new ResponseEntity(acquistoService.getQuantitaProdotto(acquisto.getUtente()), HttpStatus.NOT_FOUND);
        }
    }

}
