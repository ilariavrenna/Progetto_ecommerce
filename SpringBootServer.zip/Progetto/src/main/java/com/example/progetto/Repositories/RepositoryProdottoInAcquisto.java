package com.example.progetto.Repositories;

import com.example.progetto.entities.Acquisto;
import com.example.progetto.entities.ProdottoAcquistato;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RepositoryProdottoInAcquisto extends JpaRepository<ProdottoAcquistato, Integer> {

    //List<ProdottoAcquistato> findById_prodotto(Acquisto acquisto);
}
