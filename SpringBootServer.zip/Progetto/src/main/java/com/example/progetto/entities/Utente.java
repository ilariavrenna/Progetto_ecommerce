package com.example.progetto.entities;


import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import com.fasterxml.jackson.annotation.JsonIgnore;
import javax.persistence.*;
import javax.validation.constraints.Email;
import java.util.Set;


@Getter
@Setter
@ToString
@EqualsAndHashCode
@Entity
@Table(name="utente", schema = "progetto_psw")
public class Utente {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id", nullable = false)
    private int id;

    @Basic
    @Column(name="nome", nullable = false, length = 70)
    private String nome;

    @Basic
    @Column(name="cognome", nullable = false, length = 70)
    private String cognome;

    @Basic
    @Email
    @Column(name="email", nullable = false, length = 100, unique = true)
    private String email;

    @Basic
    @Column(name="indirizzo", nullable = false, length = 70)
    private String indirizzo;


    @Basic
    @Column(name="telefono", nullable = false, length = 70)
    private String telefono;


    @JsonIgnore
    @OneToMany(mappedBy = "utente", cascade = CascadeType.ALL)
    private Set<Acquisto> acquisti;


    @JsonIgnore
    @OneToMany(mappedBy = "utente", cascade = CascadeType.ALL)
    private Set<ProdottoCarrello> carello;

}
