import 'dart:core';
import 'package:flutter/cupertino.dart';
import '../model/objects/ProductInCart.dart';

class CartNotifier extends ChangeNotifier{

  List<ProductInCart> _listProductInCart= [];

  List<ProductInCart> get productInCart => _listProductInCart;

  void addProduct(ProductInCart p){
    if(_listProductInCart.contains(p)){
      ProductInCart productInCart= _listProductInCart.firstWhere((element) => element==p);
      productInCart.quantity+=1;
    }else{
      _listProductInCart.add(p);
    }
    notifyListeners();
  }

  void removeAllQuantityProduct(ProductInCart p){
    if(_listProductInCart.contains(p)) {
      _listProductInCart.remove(p);
      notifyListeners();
    }
  }

  void decreaseProduct(ProductInCart p){
    if(_listProductInCart.contains(p)) {
      ProductInCart productInCart = _listProductInCart.firstWhere((
          element) => element == p);
      int quantity = productInCart.quantity - 1;
      if (quantity <= 0) {
        _listProductInCart.remove(productInCart);
      } else {
        productInCart.quantity = quantity;
      }
      notifyListeners();
    }
  }

  void increaseProduct(ProductInCart p){
    if(_listProductInCart.contains(p)) {
      ProductInCart productInCart = _listProductInCart.firstWhere((
          element) => element == p);
      productInCart.quantity+=1;
      notifyListeners();
    }
  }

  void removeAllProduct(){
    _listProductInCart= [];
    notifyListeners();
  }

  void addList(List<ProductInCart> list){
    _listProductInCart=list;
    notifyListeners();
  }


}