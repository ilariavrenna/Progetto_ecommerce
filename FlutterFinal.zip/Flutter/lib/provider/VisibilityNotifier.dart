import 'package:flutter/material.dart';

class VisibilityNotifier extends ChangeNotifier {
  bool _isVisible = false;
  String _button= '';

  bool get isVisible => _isVisible;
  String get button => _button;

  void toggleVisibility(String pressedButton) {
    _isVisible = !_isVisible;
    _button= pressedButton;
    notifyListeners();
  }
}

