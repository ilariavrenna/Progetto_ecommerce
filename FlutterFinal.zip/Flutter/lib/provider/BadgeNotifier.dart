import 'package:flutter/material.dart';

class BadgeNotifier extends ChangeNotifier {

  int _value=0;

  int get value => _value;


  void setValue(int value){
    _value=value;
    notifyListeners();
  }

  void add(){
    _value++;
    notifyListeners();
  }

  void minimize(){
    _value--;
    notifyListeners();
  }

  void removeAll(int v){
    _value-=v;
    notifyListeners();
  }

  void clear(){
    //viene invocato al logout
    _value=0;
    notifyListeners();
  }




}