import 'package:flutter/material.dart';
import '../model/objects/User.dart';

class UserNotifier extends ChangeNotifier{
  User? _user;
  bool _logged=false;
  String? _role;

  bool get logged => _logged;

  User? get user => _user;

  String? get role => _role;

  void login( String role, {User? user}){
    _logged=true;
    if(user!=null) {
      _user = user;
    }
    _role=role;
    notifyListeners();
  }

  void logout(){
    _logged=false;
    _user=null;
    _role=null;
    notifyListeners();
  }

}