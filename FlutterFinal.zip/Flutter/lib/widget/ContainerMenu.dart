import 'package:app/model/support/extensions/StringCapitalization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../model/support/Constants.dart';
import '../model/support/enum/TypeSearch.dart';
import '../provider/VisibilityNotifier.dart';


class ContainerMenu extends StatefulWidget{

  ContainerMenu({super.key,  required this.size});

  double size;

  @override
  State<ContainerMenu> createState() => ContainerMenuState() ;




}

class ContainerMenuState extends State<ContainerMenu> {




  @override
  Widget build(BuildContext context) {
    final visibilityNotifier = context.watch<VisibilityNotifier>();
    return   Visibility(
      visible: visibilityNotifier.isVisible,
      child:
      InkWell(
        onTap: () {},
        onHover: (flag){
          visibilityNotifier.toggleVisibility(visibilityNotifier.button);

        },
        child:
        Container(
          height: 200,
          width: widget.size,
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 270,
                blurRadius: 70,
                offset: const Offset(30, 350), // changes position of shadow
              ),
            ],
          ),
          child:  Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 80, vertical:30),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if(visibilityNotifier.button!='')
                    for(String i in Constants.MAP_MENU[visibilityNotifier.button]!)
                      Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: TextButton(
                        onPressed: () {
                          Navigator.pushNamed(context, '/search', arguments: {"value": i, "typeCall": TypeSearch.type});
                        },
                        style: ButtonStyle(
                          overlayColor: MaterialStateProperty.all(Colors.transparent),
                          foregroundColor: MaterialStateProperty.resolveWith((states) {
                            if(states.contains(MaterialState.hovered)) {
                              return Colors.pink[300];
                            }
                            return Colors.black;
                          }),
                          textStyle: MaterialStateProperty.all(const TextStyle(
                              fontWeight: FontWeight.w500,
                              fontStyle: FontStyle.italic,
                              fontSize: 18)
                          ),
                        ),
                        child: Text(i.capitalize),

                      )
                    )
                ],
              ),
            ),
          ),

        ),
      ),
    );
  }
}