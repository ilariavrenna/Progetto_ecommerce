import 'dart:io';

import 'package:app/model/support/extensions/StringCapitalization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../Icons/custom_icon_icons.dart';
import '../model/support/enum/TypeSearch.dart';
import '../provider/BadgeNotifier.dart';
import '../provider/UserNotifier.dart';

class Header extends StatefulWidget {

  const Header({super.key, required this.size});

  final double size;

  @override
  State<Header> createState() => _HeaderState();
}

class _HeaderState extends State<Header> {
  late TextEditingController _textEditingController;

  @override
  void initState(){
    super.initState();
    _textEditingController= TextEditingController();
  }

  @override
  void dispose(){
    _textEditingController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final userNotifier= context.watch<UserNotifier>();
    final badgeNotifier= context.watch<BadgeNotifier>();
    return Padding(
      padding: const EdgeInsets.only( bottom: 25,  top: 30),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Padding(
            padding: const  EdgeInsets.only(left:40, right: 50),
            child:  GestureDetector(
              onTap: (){
                if(ModalRoute.of(context)?.settings.name!=''){
                  Navigator.pushNamed(context, '');
                }
              },
              child: Image(
                image:  const AssetImage('images/logo22.png'),
                width: widget.size * 0.2,  //300  ,
                height:  widget.size *0.05, //200,
                color: Colors.black,
              ),
            ),
          ),
          Container(
            alignment: Alignment.bottomCenter,
            width: widget.size *0.4,
            height: widget.size * 0.035,
            child: TextField(
              controller: _textEditingController ,
              onSubmitted: (String value) {
                if(value.isNotEmpty) {
                  Navigator.pushNamed(context, '/search', arguments: {
                                                        'value': value,
                                                          'typeCall' : TypeSearch.query  });
                }
              },
              cursorColor: Colors.black,
              style: const TextStyle(fontStyle: FontStyle.normal, color: Colors.black),
              textAlignVertical: TextAlignVertical.center,
              decoration: InputDecoration(
                hoverColor: Colors.red,
                focusColor: Colors.blue,
                fillColor: Colors.pink,
                focusedBorder: const OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(40.0)),
                    borderSide: BorderSide(color: Colors.black)
                ),
                border:const  OutlineInputBorder(
                  borderRadius: BorderRadius.all(Radius.circular(40.0),),
                ),
                hintText: 'Cosa stai cercando?',
                hintStyle: TextStyle(fontSize: widget.size <1050 ? 14: 16,),
                prefixIcon: Icon(CustomIcon.search, size: widget.size *  0.01 /*20,*/),
              ),

            ),
          ),
          Padding(
            padding: EdgeInsets.only( left: widget.size<950 ? 30:40),
            child: TextButton.icon(
              onPressed: () {
                //Saltiamo alla nuova pagina
                if(userNotifier.logged){
                  if(ModalRoute.of(context)?.settings.name!='/profile') {
                     Navigator.pushNamed(context, '/profile');
                  }
                }else {
                  if(ModalRoute.of(context)?.settings.name!='/account') {
                    Navigator.pushNamed(context, '/account');
                  }
                }
              },
              icon: const Icon(CustomIcon.user_2, size: 25),
              label: userNotifier.logged? Text.rich(
                              TextSpan(
                                text: 'Ciao ',
                                style: DefaultTextStyle.of(context).style,
                                children: <TextSpan>[
                                      TextSpan(
                                          text: userNotifier.user?.nome.capitalize ?? " ",
                                          style: const TextStyle(
                                            fontWeight: FontWeight.bold,
                                          ),
                                      ),
                                ],
                              ),
                  ) : const Text('Accedi'),
              style: ButtonStyle(
                foregroundColor: MaterialStateProperty.all<Color>(Colors.black),
              ),),
          ),
          Padding(
            padding:  EdgeInsets.only( left: widget.size<950?20: 30),
            child: Badge(
              backgroundColor: Colors.pink,
              smallSize: 0,
              label: Text(badgeNotifier.value.toString()),
              child: TextButton.icon(
                onPressed: () {
                  if(ModalRoute.of(context)?.settings.name!='/cart') {
                    Navigator.pushNamed(context, '/cart');
                    }
                  },
                icon: const Icon(CustomIcon.cart, size: 25),
                label: const Text('Carrello'),
                style: ButtonStyle(
                  foregroundColor: MaterialStateProperty.all<Color>(Colors.black),
                ),),
            ),
          ),
        ],
      ),
    );
  }
}
