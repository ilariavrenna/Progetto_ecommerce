import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class FormText extends StatefulWidget {

  FormText({super.key, required this.controller, required this.label});

  TextEditingController controller;
  String label;

  @override
  State<FormText> createState() => _FormTextState();
}

class _FormTextState extends State<FormText> {



  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: widget.controller ,
      cursorColor: Colors.black,
      cursorHeight: 20,
      cursorWidth: 1,
      decoration:   InputDecoration(
        focusedBorder:  const  UnderlineInputBorder(
            borderSide: BorderSide( color:  Colors.black)
        ),
        labelText: widget.label,
        labelStyle: const TextStyle(fontStyle: FontStyle.italic, color: Colors.black),
      ),
      onSubmitted: (_)=>setState(() {} ),
    );
  }
}
