import 'package:flutter/material.dart';

class CircularActionButton extends StatefulWidget {

   const CircularActionButton({super.key, required this.function, required this.icon });

  final void Function() function;
  final Icon icon;

  @override
  State<CircularActionButton> createState() => _CircularActionButtonState();
}

class _CircularActionButtonState extends State<CircularActionButton> {
  @override
  Widget build(BuildContext context) {
    return FloatingActionButton(
        onPressed: widget.function,
      backgroundColor:  Theme.of(context).colorScheme.inversePrimary,
      shape: const CircleBorder(),
      child: widget.icon
    );
  }
}
