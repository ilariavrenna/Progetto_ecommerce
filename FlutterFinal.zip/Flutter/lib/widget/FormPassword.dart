import 'dart:js_interop';

import 'package:app/model/support/Constants.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../Icons/custom_icon2_icons.dart';

class FormPassword extends StatefulWidget {

  FormPassword({super.key, required this.controllerPsw, required this.label,  this.callback});

  TextEditingController controllerPsw;
  String label;
  final Function()? callback;

  @override
  State<FormPassword> createState() => _FormPasswordState();
}

class _FormPasswordState extends State<FormPassword> {


  bool _isObscure= true;

  String? get _errorTextPsw{
    final text= widget.controllerPsw.value.text;
    if(text.isNotEmpty && text.length<Constants.LENGTH_PASSWORD) {
      return "Lunghezza richiesta é di 8 caratteri";
    }
    return null;
  }




  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: widget.controllerPsw,
      cursorColor: Colors.black,
      cursorHeight: 20,
      cursorWidth: 1,
      obscureText: _isObscure,
      decoration: InputDecoration(
        focusedBorder: const UnderlineInputBorder(
            borderSide: BorderSide( color:  Colors.black)
        ),
        labelText: widget.label,
        labelStyle: const TextStyle(fontStyle: FontStyle.italic, color: Colors.black),
        suffixIcon: !_isObscure?  IconButton(
          icon: const Icon(CustomIcon2.eye_off_1, size: 20), onPressed: (){
          setState(() {
            _isObscure=!_isObscure;
          });
        },) : IconButton(
          icon: const Icon(CustomIcon2.eye_3, size: 20,),
          onPressed: (){
            setState(() {
              _isObscure=!_isObscure;
            });
          },
        ),
        errorText: _errorTextPsw,
      ),
      onChanged: (_) {
        setState(()
             { });
        if(widget.callback!=null) {
          widget.callback!();
        }
      }
    );
  }
}
