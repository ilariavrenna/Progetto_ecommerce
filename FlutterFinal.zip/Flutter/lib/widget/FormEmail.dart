import 'package:email_validator/email_validator.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class FormEmail extends StatefulWidget {

  FormEmail({super.key, required this.controllerEmail});

  TextEditingController controllerEmail;

  @override
  State<FormEmail> createState() => _FormEmailState();
}

class _FormEmailState extends State<FormEmail> {

  @override
  void initState(){
    super.initState();
  }

  String? get _errorTextEmail{
    final text = widget.controllerEmail.value.text;
    if(text.isNotEmpty && !EmailValidator.validate(text)){
      return "Formato e-mail non valido";
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: widget.controllerEmail,
      cursorColor: Colors.black,
      cursorHeight: 20,
      cursorWidth: 1,
      decoration:  InputDecoration(
        focusedBorder:  const UnderlineInputBorder(
            borderSide: BorderSide( color:  Colors.black)
        ),
        labelText: "E-mail",
        labelStyle: const TextStyle(fontStyle: FontStyle.italic, color: Colors.black),
        errorText: _errorTextEmail,
      ),
      onChanged: (_){ setState(() { });} ,
    );
  }
}


