import 'package:app/model/support/enum/TypeSearch.dart';
import 'package:app/model/support/extensions/StringCapitalization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../model/support/Constants.dart';
import '../provider/VisibilityNotifier.dart';


class ButtonMenu extends StatefulWidget{

  ButtonMenu({super.key, required  this.nameButton});

  String nameButton;

  State<ButtonMenu> createState() => ButtonMenuState();



}

class ButtonMenuState extends State<ButtonMenu>{

  @override
  Widget build(BuildContext context) {
    final visibilityNotifier = context.watch<VisibilityNotifier>();
    return  TextButton(
        onPressed: (){

            //Ricerco i prodotti per categoria
          Navigator.pushNamed(context, '/search', arguments: {"value":widget.nameButton, "typeCall": TypeSearch.category});

          },
        onHover: (flag){
          visibilityNotifier.toggleVisibility(widget.nameButton);
        },
        style: ButtonStyle(
          overlayColor: MaterialStateProperty.all(Colors.transparent),
          foregroundColor: MaterialStateProperty.resolveWith((states) {
              if(states.contains(MaterialState.hovered)) {
                return Colors.pink[300];
                            }
            return Colors.black;
          }),
          textStyle: MaterialStateProperty.all(const TextStyle(
              fontWeight: FontWeight.w400,
              fontStyle: FontStyle.normal,
              fontSize: 20)
          ),
        ),
        child:  Text(widget.nameButton.capitalize));
  }




}
