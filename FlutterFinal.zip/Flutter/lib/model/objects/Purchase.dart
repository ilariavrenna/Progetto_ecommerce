import 'dart:convert';

import 'ProductInPurchase.dart';
import 'User.dart';

class Purchase{

  final int? numeroOrdine;
  final User utente;
  final double prezzo;
  final DateTime? data;
  final List<ProductInPurchase>? listaProdottiAcquistati;

  const Purchase({ this.numeroOrdine, required this.utente, this.data, required this.prezzo, this.listaProdottiAcquistati});

  factory Purchase.fromJson(Map<String, dynamic> json){
    return Purchase(numeroOrdine: json["numeroOrdine"], utente: User.fromJson(json["utente"]),
      prezzo: json["prezzo"],  data: DateTime.fromMillisecondsSinceEpoch(json["dataAcquisto"]),
      listaProdottiAcquistati: List<ProductInPurchase>.from((json["listaProdottiAcquistati"]).map((i) => ProductInPurchase.fromJson(i)))
    );
  }

  Map<String, dynamic> toJson() =>{
    'utente' : utente,
    'prezzo' : prezzo,
    'listaProdottiAcquistati' : listaProdottiAcquistati
  };

}