class User{

  final int? id;
  final String nome;
  final String cognome;
  final String email;
  final String indirizzo;
  final String telefono;


  const User({this.id, required this.nome, required this.cognome, required this.email, required this.indirizzo, required this.telefono});


  factory User.fromJson(Map<String, dynamic> json){
    return User(id: json["id"], nome: json["nome"], cognome: json["cognome"], email: json["email"], indirizzo: json["indirizzo"], telefono: json["telefono"]);
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'nome': nome,
    'cognome': cognome,
    'email': email,
    'indirizzo': indirizzo,
    'telefono': telefono,
  };

}