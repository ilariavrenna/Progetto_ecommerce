import 'package:app/model/objects/Product.dart';

import 'User.dart';

class ProductInCart{

  final int?  id;
  int quantity;
  final Product product;
  final User? user;


  ProductInCart({this.id, required this.quantity, required this.product, this.user});

  factory ProductInCart.fromJson(Map<String, dynamic> json){
    return ProductInCart(
        id: json["id"],
        quantity: json["quantita"],
        product: Product.fromJson(json["prodottoid"]),
        user: User.fromJson(json["utente"]));
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'quantita': quantity,
    'prodottoid': product,
    'utente': user,
  };

  @override
  bool operator ==(Object other){
    if(identical(this, other)) return true;
    return other is ProductInCart && product==other.product;
  }

  @override
  int get hashCode => product.hashCode;

}