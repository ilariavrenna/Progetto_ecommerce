class Product{

  final int? id;
  final String nome;
  final String codice;
  final String descrizione;
  final String categoria;
  final String tipo;
  final String marca;
  final double prezzo;
  final int quantita;
  final String immagine;

  const Product({ this.id, required this.nome, required this.codice, required this.descrizione, required this.categoria, required this.tipo, required this.marca, required this.prezzo, required this.quantita, required this.immagine});

  factory Product.fromJson(Map<String, dynamic> json){
    return Product(id: json["id"], nome: json["nome"], codice: json["codice"], descrizione: json["descrizione"], categoria: json["categoria"], tipo: json["tipo"], marca: json["marca"], prezzo: json["prezzo"], quantita: json["quantita"], immagine: json["immagine"]);
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'nome': nome,
    'codice': codice,
    'descrizione': descrizione,
    'categoria': categoria,
    'tipo': tipo,
    'marca': marca,
    'prezzo': prezzo,
    'quantita': quantita,
    'immagine': immagine,
  };

  @override
  bool operator ==(Object other){
    if(identical(this, other)) return true;
    return other is Product && id==other.id && codice==other.codice;
  }

  @override
  int get hashCode => id.hashCode+codice.hashCode;




}