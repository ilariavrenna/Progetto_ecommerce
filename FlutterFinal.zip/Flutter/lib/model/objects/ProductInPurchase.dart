import 'package:app/model/objects/Product.dart';

class ProductInPurchase{

  final int? id;
  final double prezzo;
  final int quantita;
  final Product prodotto;

  const ProductInPurchase({this.id, required this.prezzo, required this.quantita, required this.prodotto});

  factory ProductInPurchase.fromJson(Map<String, dynamic> json){
    return ProductInPurchase(id: json["id"], prezzo: json["prezzo"],
        quantita: json["quantita"], prodotto: Product.fromJson(json["prodotto"]));
  }

  Map<String, dynamic> toJson( ) => {
    'prezzo' : prezzo,
    'quantita' : quantita,
    'prodotto' : prodotto
  };

}