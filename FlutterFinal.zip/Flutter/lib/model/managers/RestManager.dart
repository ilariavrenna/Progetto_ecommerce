import 'dart:convert';
import 'dart:io';
import 'package:app/model/support/Constants.dart';
import 'package:http/http.dart';
import '../support/enum/TypeHeader.dart';


class RestManager{

  String? token;


  Future<Response?> _makeRequest(String serverAddress, String servicePath, String method, TypeHeader type, { Map<String, dynamic>? value, dynamic body} ) async{
    late Uri uri;
    if(serverAddress==Constants.ADDRESS_SERVER) {
      uri = Uri.http(serverAddress, servicePath, value);
    }else if(serverAddress==Constants.ADDRESS_AUTHENTICATION_SERVER){
      uri = Uri.http(serverAddress, servicePath, value);
    }
    print("$uri son qui");
    bool errorOccurred= false;
    while(true){
      try{
        late Response response;
        late String contentType;
        dynamic formattedBody;
        if(type==TypeHeader.json){
          contentType="application/json;charset=utf-8";
          formattedBody= json.encode(body);
        } else if(type==TypeHeader.urlencoded){
          contentType= "application/x-www-form-urlencoded";
          formattedBody= body.keys.map((key) => "$key=${body[key]}").join("&");
        }
        Map<String, String> headers= {};
        headers[HttpHeaders.contentTypeHeader]= contentType;
        if(token !=null){
          headers[HttpHeaders.authorizationHeader]= 'Bearer $token';
        }
        switch(method){
          case "post":
            response= await post(
              uri,
              headers: headers,
              body: formattedBody
            );
            break;
          case "get":
            response=  await get(
                uri,
                headers: headers
            );
            break;
          case "put":
            response = await put(
              uri,
              headers: headers,
              body: formattedBody
            );
            break;
          case "delete":
            response= await delete(
              uri,
              headers: headers,
            );
            break;
        }
        if(errorOccurred){
          errorOccurred=false;
        }
        return response;
      }catch(err){
        if(!errorOccurred){
          errorOccurred= true;
        }
        await Future.delayed(const Duration(seconds: 5), () => null);
      }
   }
  }

  Future<Response?> makePostRequest(String serverAddress, String servicePath, dynamic value, TypeHeader type ) async {
    return _makeRequest(serverAddress, servicePath, "post", type, body: value);
  }

  Future<Response?> makeGetRequest(String serverAddress, String servicePath, TypeHeader type, [Map<String, dynamic>? value]) async {
    return _makeRequest(serverAddress, servicePath, "get", type, value: value);
  }

  Future<Response?> makePutRequest(String serverAddress, String servicePath, TypeHeader type, {Map<String, dynamic>? value, dynamic? body}) async {
    return _makeRequest(serverAddress, servicePath, "put", type, value: value, body: body);
  }

  Future<Response?> makeDeleteRequest(String serverAddress, String servicePath,TypeHeader type, [Map<String, dynamic>? value]) async {
    return _makeRequest(serverAddress, servicePath, "delete", type, value: value);
  }



}