extension StringCapitalization on String {

  String get capitalize => '${this[0].toUpperCase()}${this.substring(1)}';

  String get capitalizeAll {
    List<String> list= split(" ");
    String result= "";
    for (int i = 0; i < list.length; i++) {
      result += list[i].capitalize;
      if (i < list.length - 1) {
        result += ' ';
      }
    }
    return result;
  }

}