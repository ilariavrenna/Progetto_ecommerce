enum TypeSearch{
  category,
  type,
  query,
  searchAdvanced
}