enum RegisterResult{
  signUp,
  error,
  errorEmailExist
}