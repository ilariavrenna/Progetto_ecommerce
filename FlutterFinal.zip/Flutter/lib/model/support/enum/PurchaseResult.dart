enum PurchaseResult{
  completated,
  error,
  notFoundQuantity;
}