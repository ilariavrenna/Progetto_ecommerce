enum LogInResult {
  logged,
  error_wrong_credentials,
  error_not_fully_setupped,
  error_unknown,
}