class Constants{

 // final String ;

  // addresses
  static const String ADDRESS_SERVER = "localhost:8080";
  static const String ADDRESS_AUTHENTICATION_SERVER = "localhost:8081";
  static const CLIENT_ID= "app-flutter";
  static const CLIENT_SECRET= "wqom23oFFt7WWtBb0wD9BSQzCKWkKcav";

  // path
  static const String REQUEST_ALL_PRODUCTS = "/product/all";
  //static const String REQUEST_ALL_PRODUCTS = "/product/hello";
  static const String REQUEST_PRODUCTS_FOR_CATEGORY= "/product/category";
  static const String REQUEST_PRODUCTS_FOR_TYPE= "/product/type";
  static const String REQUEST_PRODUCTS_FOR_QUERY= "/product/search";
  static const String REQUEST_PRODUCTS_FOR_SEARCH_ADVANCED= "/product/searchAdvanced";
  static const String REQUEST_REGISTARTION= "/user/registration";
  static const String REQUEST_LOGIN= "/user/login";
  static const String REQUEST_LOGIN_KEYCLOAK= "/realms/store-dev/protocol/openid-connect/token";
  static const String REQUEST_LOGOUT_KEYCLOAK= "/realms/store-dev/protocol/openid-connect/revoke";
  static const String REQUEST_ADD_CART= "/carrello";
  static const String REQUEST_GET_CART= "/carrello/utente";
  static const String REQUEST_GET_QUANTITY_PRODUCT_CART= "/carrello/quantita/prodotti";
  static const String REQUEST_ALL_PURCHASES= "/ordine/all";
  static const String REQUEST_MAKE_PURCHASE= "/ordine/checkout";
  static const String REQUEST_USER_INFO= "/user/info";
  static const String REQUEST_UPDATE_PRODUCT= "/product/update";
  static const String REQUEST_ADD_PRODUCT= "/product/add";




  //static const String PATH_IMAGES= "C:\Users\\utente\\Desktop\\ilaria\\images\\";

 // static const String REQUEST_ADD_USER = "/users";


  //messages
  static const String MESSAGE_CONNECTION_ERROR = "connection_error";


  //path
  static const String PATH_IMAGES= "http://localhost:8080/product/image/";
  //static const String PATH_IMAGES= "https://localhost:443/product/image/";
  static const String PATH_IMAGE= "images/";


  //messagges
 static const String ADD_TO_CART= "AGGIUNGI AL CARRELLO";
 static const String NO_PRODUCT= "NON DISPONIBILE";
 static const String MESSAGE_ERROR_LOAD= "Errore durante il processo di caricamento...";
 static const String MESSAGE_NOT_FOUND_PRODUCT="Nessun prodotto corrisponde alla tua ricerca...";
 static const String ERROR_NOT_COMPILE_FORM= "Attenzione. Assicurati di compilare tutti i campi prima di procedere.";
 static const String SIGNUP_FAILED= "La registrazione utente non è andata a buon fine. Verifica le tue informazioni e riprova.";
 static const String ERROR_EMAIL_EXSIST= "Registrazione fallita. Esiste già un account con questo indirizzo email. Per favore, utilizza un indirizzo email diverso o accedi con il tuo account esistente.";
 static const String SIGNUP= "Registrazione completata con successo! Ora puoi procedere con il login per accedere al tuo account.";
 static const String MESSAGE_CART_LOGIN ="Per aggiungere un prodotto al carrello, è necessario effettuare il login";
 static const String MESSAGE_CART_ERROR ="Siamo spiacenti, ma non è possibile aggiungere il prodotto al carrello.";
 static const String MESSAGE_PRODUCT_CART_LOGIN= "Benvenuto nel tuo carrello! Per visualizzare i prodotti e procedere con l'acquisto, ti preghiamo di effettuare il login.";
 static const String MESSAGE_CART_EMPTY= "Il tuo carrello è vuoto.";
 static const String MESSAGE_PURCHASE_OK= "Acquisto completato con successo.";
 static const String MESSAGE_PURCHASE_NO= "Purtroppo il tuo tentativo di acquisto non è stato completato con successo.";
 static const String MESSAGE_CART_UPDATE= "Siamo spiacenti, non è possibile completare l'acquisto. Il tuo carrello è stato aggiornato automaticamente con le quantità disponibili. Si prega di rivedere il carrello prima di procedere con l'acquisto.";
  static const String MESSAGE_PURCHASE_LOGIN= "Per completare l'ordine, è necessario effettuare il login";
  static const String MESSAGE_QUANTITY_ERROR= "La quantità non può essere inferiore a 0.";
  static const String MESSAGE_PRICE_ERROR= "Il prezzo deve essere maggiore di 0.";
  static const String MESSAGE_UPDATE_ERROR= "Non é stato possibile completare l'operazione. Si prega di ricontrollare i dati inseriti.";
  static const String MESSAGE_UPDATE_SUCCESS= "I dati sono stati correttamente aggiornati";
  //const
  static const int LENGTH_PASSWORD=8;
  static const int INITIAL_PAGE=0;
  static const int SIZE_PAGE=6;
  static const int SIZE_PAGE_ADMIN=5;
  static const double START_RANGE=0, END_RANGE= 100;
  static const List<String> INFO_USER= ["nome", "cognome", "email", "indirizzo", "telefono" ];
  static const List<String> MENU= ["viso", "occhi", "labbra", "accessori"];
 static const  Map<String, List<String>> MAP_MENU= {
    'viso': ['cipria', 'correttore', 'blush', 'bronzer', 'illuminante', 'fondotinta'],
    'occhi': ['mascara', 'matita', 'ombretto', 'eyeliner'],
    'labbra': ['rossetto', 'gloss', 'matita'],
    'accessori': ['pennelli', 'spugnette', 'piegaciglia', 'temperamatite']
  };
 static const List<String> MARCA= ["DIOR",
                                    "PUPA",
                                    "MAC",
                                    "LANCOME",
                                    "CHANEL",
                                    "CLINIQUE",
                                    "MAX FACTOR",
                                    "DEBORAH",
                                    "MULAC",
                                    "DIEGO DELLA PALMA"];


}