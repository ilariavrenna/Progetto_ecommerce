
import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:app/model/managers/RestManager.dart';
import 'package:app/model/objects/Product.dart';
import 'package:app/model/objects/ProductInCart.dart';
import 'package:app/model/objects/Purchase.dart';
import 'package:app/model/objects/User.dart';
import 'package:app/model/support/Constants.dart';
import 'package:app/model/support/enum/LogInResult.dart';
import 'package:app/model/support/enum/PurchaseResult.dart';
import 'package:app/model/support/enum/RegisterResult.dart';
import 'package:app/model/support/enum/TypeHeader.dart';
import 'package:http/http.dart';

import 'objects/AuthenticationData.dart';

class Model {

  static Model sharedInstance = Model();

  final RestManager _restManager = RestManager();

  Timer? _refreshTimer;

  late AuthenticationData _authenticationData;


  Future<List<Product>> getAllProduct(
      {int? pageNumber, int? pageSize, String? pageSort}) async {
    Map<String, String> params = Map();
    if (pageNumber != null) {
      params["pageNumber"] = pageNumber.toString();
    }
    if (pageSize != null) {
      params["pageSize"] = pageSize.toString();
    }
    if (pageSort != null) {
      params["pageSort"] = pageSort.toString();
    }
    List<Product> list = [];
    Response? response;
    if(params.isNotEmpty) {
      response = await _restManager.makeGetRequest(
          Constants.ADDRESS_SERVER, Constants.REQUEST_ALL_PRODUCTS,
          TypeHeader.json, params);
    }else{
      response = await _restManager.makeGetRequest(
          Constants.ADDRESS_SERVER, Constants.REQUEST_ALL_PRODUCTS,
          TypeHeader.json);
    }
    List<dynamic> result = json.decode(response!.body); //Lista di json
    for (var product in result) {
      list.add(Product.fromJson(product));
    }
    return list;
  }

  Future<List<Product>> getProductForCategory(String category, {int? pageNumber, int? pageSize, String? pageSort}) async {
    Map<String, String> params = {};
    if (pageNumber != null) {
      params["pageNumber"] = pageNumber.toString();
    }
    if (pageSize != null) {
      params["pageSize"] = pageSize.toString();
    }
    if (pageSort != null) {
      params["pageSort"] = pageSort.toString();
    }
    List<Product> list= [];
    Response? response;
    if(params.isNotEmpty){
      response= await _restManager.makeGetRequest(
          Constants.ADDRESS_SERVER,
          '${Constants.REQUEST_PRODUCTS_FOR_CATEGORY}/$category',
          TypeHeader.json, params);
    }else{
      response= await _restManager.makeGetRequest(
          Constants.ADDRESS_SERVER,
          '${Constants.REQUEST_PRODUCTS_FOR_CATEGORY}/$category',
          TypeHeader.json);
    }
    List<dynamic> result= json.decode(response!.body); //Lista di json
    for (var product in result) {
      list.add(Product.fromJson(product));
    }
    return list;
  }

  Future<List<Product>> getProductForType(String type, {int? pageNumber, int? pageSize, String? pageSort}) async{
    Map<String, String> params = {};
    if (pageNumber != null) {
      params["pageNumber"] = pageNumber.toString();
    }
    if (pageSize != null) {
      params["pageSize"] = pageSize.toString();
    }
    if (pageSort != null) {
      params["pageSort"] = pageSort.toString();
    }
    List<Product> list = [];
    Response? response;
    if(params.isNotEmpty) {
      response = await _restManager.makeGetRequest(
          Constants.ADDRESS_SERVER,
          '${Constants.REQUEST_PRODUCTS_FOR_TYPE}/$type',
          TypeHeader.json, params);
    }else{
      response = await _restManager.makeGetRequest(
          Constants.ADDRESS_SERVER,
          '${Constants.REQUEST_PRODUCTS_FOR_TYPE}/$type',
          TypeHeader.json);
    }
    List<dynamic> result= json.decode(response!.body); //Lista di json
    for (var product in result) {
      list.add(Product.fromJson(product));
    }
    return list;
  }

  Future<List<Product>> getProductQuery (String query, {int? pageNumber, int? pageSize, String? pageSort}) async{
    Map<String, String> params= {};
    if(pageNumber!=null){
      params["pageNumber"]= pageNumber.toString();
    }
    if(pageSize!=null){
      params["pageSize"]= pageSize.toString();
    }
    if(pageSort!=null){
      params["pageSort"]= pageSort;
    }
    params["query"]= query;
    Response? response= await _restManager.makeGetRequest(
        Constants.ADDRESS_SERVER,
        Constants.REQUEST_PRODUCTS_FOR_QUERY,
        TypeHeader.json, params);
    List<Product> list= [];
    List<dynamic> result= json.decode(response!.body); //Lista di json
    for (var product in result) {
      list.add(Product.fromJson(product));
    }
    return list;
  }

  Future<List<Product>> getRicercaAvanzata(String valueRequest, {List<String>? brands, int? minPrice, int? maxPrice, int? pageNumber, int? pageSize, String? pageSort}) async {
    Map<String, dynamic> params={};
    params["query"]=valueRequest;
    if(minPrice!=null && minPrice!=Constants.START_RANGE) {
      params["minPrice"] = minPrice.toString();
    }
    if(maxPrice!=null && maxPrice!=Constants.END_RANGE){
      params["maxPrice"]= maxPrice.toString();
    }
    if(pageNumber!=null){
      params["pageNumber"]= pageNumber.toString();
    }
    if(pageSize!=null){
      params["pageSize"]= pageSize.toString();
    }
    if(pageSort!=null){
      params["pageSort"]= pageSort;
    }
    if(brands!=null){
      params["marca"]= brands;
    }
    Response? response= await _restManager.makeGetRequest(
        Constants.ADDRESS_SERVER, Constants.REQUEST_PRODUCTS_FOR_SEARCH_ADVANCED,TypeHeader.json, params);
    List<Product> list= [];
    List<dynamic> result= json.decode(response!.body); //Lista di json
    for (var product in result) {
      list.add(Product.fromJson(product));
    }
    return list;
  }

  Future<LogInResult> login(String email, String password) async{
    try {
      Map<String, String> params = {};
      params["grant_type"] = "password";
      params["client_id"] = Constants.CLIENT_ID;
      params["client_secret"] = Constants.CLIENT_SECRET;
      params["username"] = email;
      params["password"] = password;
      print("login post");
      Response? response = await _restManager.makePostRequest(
          Constants.ADDRESS_AUTHENTICATION_SERVER,
          Constants.REQUEST_LOGIN_KEYCLOAK, params, TypeHeader.urlencoded);
      if(response==null){
        return LogInResult.error_unknown;
      }
      _authenticationData =
          AuthenticationData.fromJson(jsonDecode(response!.body));
      if (_authenticationData.hasError()) {
        if (_authenticationData.error == "Invalid user credentials") {
          return LogInResult.error_wrong_credentials;
        }
        else if (_authenticationData.error == "Account is not fully set up") {
          return LogInResult.error_not_fully_setupped;
        }
        else {
          return LogInResult.error_unknown;
        }
      }
      _restManager.token = _authenticationData.accessToken;
     _refreshTimer= Timer.periodic(
          Duration(seconds: (_authenticationData.expiresIn! - 50)), (Timer t) {
        _refreshToken();
      });
      return LogInResult.logged;
    } catch (e) {
          return LogInResult.error_unknown;
    }
  }

  Future<bool> _refreshToken() async {
    try {
      Map<String, String> params = Map();
      params["grant_type"] = "refresh_token";
      params["client_id"] = Constants.CLIENT_ID;
      params["client_secret"] = Constants.CLIENT_SECRET;
      params["refresh_token"] = _authenticationData.refreshToken!;
      Response? result = await _restManager.makePostRequest(
          Constants.ADDRESS_AUTHENTICATION_SERVER,
          Constants.REQUEST_LOGIN_KEYCLOAK, params, TypeHeader.urlencoded);
      _authenticationData =
          AuthenticationData.fromJson(jsonDecode(result!.body));
      if (_authenticationData.hasError()) {
        return false;
      }
      _restManager.token = _authenticationData.accessToken;
      return true;
    }
    catch (e) {
      return false;
    }
  }

  Future<bool> logout( ) async{
    if(_refreshTimer!=null){
      _refreshTimer!.cancel();
    }
    Map<String, String> params= {};
    params["token_type_hint"] = "refresh_token";
    params["client_id"] = Constants.CLIENT_ID;
    params["client_secret"] = Constants.CLIENT_SECRET;
    params["token"] = _authenticationData.refreshToken!;
    print( _authenticationData.refreshToken!);
    Response? response= await _restManager.makePostRequest(
    Constants.ADDRESS_AUTHENTICATION_SERVER, Constants.REQUEST_LOGOUT_KEYCLOAK, params, TypeHeader.urlencoded);
    if(response!=null && response.statusCode==HttpStatus.ok) {
      _restManager.token=null;
      return true;
    }
    return false;
  }

  Future<User> getUtente(List<ProductInCart> carrello) async{
    Response? response= await _restManager.makePostRequest(Constants.ADDRESS_SERVER, Constants.REQUEST_LOGIN, carrello ,TypeHeader.json);
    return User.fromJson(jsonDecode(response!.body));
  }




  Future<RegisterResult> signUp(User user, String password) async {
    Map<String, dynamic> body= Map();
    body["utente"]= user.toJson();
    body["password"]= password;
    Response? response= await _restManager.makePostRequest(Constants.ADDRESS_SERVER, Constants.REQUEST_REGISTARTION, body, TypeHeader.json);
    if(response==null){
      return RegisterResult.error;
    }else if(response.statusCode == HttpStatus.created){
      return RegisterResult.signUp;
    }else if(response.statusCode== HttpStatus.conflict){
      return RegisterResult.errorEmailExist;
    }
    return RegisterResult.error;

  }

  Future<bool> addToCart(User user, String code) async{
    Response? response= await _restManager.makePostRequest(Constants.ADDRESS_SERVER,
        '${Constants.REQUEST_ADD_CART}/$code', user.toJson(), TypeHeader.json);
    if(response==null){
      return false;
    }else if(response.statusCode== HttpStatus.ok){
      return true;
    }else{
      return false;
    }
  }

  Future<List<ProductInCart>> getCart(/*User user*/) async{
   /* Response? response= await _restManager.makePostRequest(Constants.ADDRESS_SERVER,
        Constants.REQUEST_GET_CART, user.toJson(),TypeHeader.json);*/
    Response? response= await _restManager.makeGetRequest(Constants.ADDRESS_SERVER,
        Constants.REQUEST_GET_CART, TypeHeader.json);
    List<ProductInCart> result= [];
    if(response!=null && response.statusCode==HttpStatus.ok){
      //print("Body: ${jsonDecode(response.body)}");
      for(var pc in jsonDecode(response.body)){
        result.add(ProductInCart.fromJson(pc));
      }
    }
    return result;
  }
  
  Future<List<ProductInCart>> increaseProductInCart(String codeProduct) async{
    Response? response= await _restManager.makePutRequest(Constants.ADDRESS_SERVER, "/carrello/prodotto/${codeProduct}/incrementa", TypeHeader.json);
    List<ProductInCart> result= [];
    if(response!=null && response.statusCode==HttpStatus.ok){
      for(var pc in jsonDecode(response.body)){
        result.add(ProductInCart.fromJson(pc));
      }
    }
    return result;
  }

  Future<List<ProductInCart>> decreaseProductInCart(String codeProduct) async{
    Response? response= await _restManager.makePutRequest(Constants.ADDRESS_SERVER, "/carrello/prodotto/${codeProduct}/decrementa", TypeHeader.json);
    List<ProductInCart> result= [];
    if(response!=null && response.statusCode==HttpStatus.ok){
      for(var pc in jsonDecode(response.body)){
         result.add(ProductInCart.fromJson(pc));
      }
    }
    return result;
  }

  Future<List<ProductInCart>> deleteProductInCart(String codeProduct) async{
    Response? response= await _restManager.makeDeleteRequest(Constants.ADDRESS_SERVER, "/carrello/prodotto/${codeProduct}/elimina", TypeHeader.json);
    List<ProductInCart> result= [];
    if(response!=null && response.statusCode==HttpStatus.ok){
      for(var pc in jsonDecode(response.body)){
        result.add(ProductInCart.fromJson(pc));
      }
    }
    return result;
  }

  Future<List<ProductInCart>> deleteAllProductInCart() async{
    Response? response= await _restManager.makeDeleteRequest(Constants.ADDRESS_SERVER, "/carrello/svuota", TypeHeader.json);
    List<ProductInCart> result= [];
    if(response!=null && response.statusCode==HttpStatus.ok){
      for(var pc in jsonDecode(response.body)){
        result.add(ProductInCart.fromJson(pc));
      }
    }
    return result;
  }

  Future<int> getQuantityProductInCart() async{
    Response? response= await _restManager.makeGetRequest(Constants.ADDRESS_SERVER, Constants.REQUEST_GET_QUANTITY_PRODUCT_CART, TypeHeader.json);
    if(response!=null && response.statusCode==HttpStatus.ok){
      return jsonDecode(response.body);
    }
    return -1;
  }

  Future<List<Purchase>> getAllPurchases({int? pageNumber, int? pageSize, String? pageSort}) async{
    Map<String, String> params={};
    if(pageNumber!=null) {
      params["pageNumber"]= pageNumber.toString();
    }
    if(pageSize!=null){
      params["pageSize"]=pageSize.toString();
    }
    if(pageSort!=null){
      params["pageSort"]=pageSort;
    }
    Response? response= await _restManager.makeGetRequest(Constants.ADDRESS_SERVER, Constants.REQUEST_ALL_PURCHASES, TypeHeader.json,  params);
    List<Purchase> result=[];
    if(response!=null && response.statusCode==HttpStatus.ok){
      for(var purchase in jsonDecode(response.body)) {
        result.add(Purchase.fromJson(purchase));
      }
    }
    return result;
  }

  Future<Map<String, dynamic>> makePurchase(Purchase p) async{
    Response? response= await _restManager.makePostRequest(Constants.ADDRESS_SERVER, Constants.REQUEST_MAKE_PURCHASE, p.toJson(), TypeHeader.json);
    Map<String, dynamic> result= {};
    if(response!=null && response.statusCode==HttpStatus.ok){
     Purchase purchase= Purchase.fromJson(jsonDecode(response.body));
     result["response"]=PurchaseResult.completated;
     result["result"]=purchase;
     return result;
    }
    if(response!=null && (response.statusCode==HttpStatus.notFound || response.statusCode==HttpStatus.conflict)){
      List<ProductInCart> purchase= List<ProductInCart>.from((jsonDecode(response.body).map((i) => ProductInCart.fromJson(i))));
      result["response"]=PurchaseResult.notFoundQuantity;
      result["result"]=purchase;
      return result;
    }
    result["response"]=PurchaseResult.error;
    result["purchase"]=null;
    return result;
  }

  Future<User?> getUserInfo() async {
    Response? response= await _restManager.makeGetRequest(Constants.ADDRESS_SERVER, Constants.REQUEST_USER_INFO, TypeHeader.json);
    if(response!=null && response.statusCode==HttpStatus.ok){
      User result= User.fromJson(jsonDecode(response.body));
      return result;
    }
    return null;
  }

  Future<Product?> updateProduct(String codeProduct, int quantity, double price) async {
    Map<String, dynamic> body = {};
    body["codeProduct"] = codeProduct;
    body["quantity"] = quantity;
    body["price"] = price;
    Response? response = await _restManager.makePutRequest(
        Constants.ADDRESS_SERVER, Constants.REQUEST_UPDATE_PRODUCT,
        TypeHeader.json, body: body);
    if (response != null && response.statusCode == HttpStatus.ok) {
      Product result = Product.fromJson(jsonDecode(response.body));
      return result;
    }
    return null;
  }

  Future<bool> addProduct(Product p) async{
    Response? response= await _restManager.makePostRequest(Constants.ADDRESS_SERVER, Constants.REQUEST_ADD_PRODUCT, p.toJson(), TypeHeader.json);
    if(response!=null && response.statusCode == HttpStatus.ok){
      return true;
    }
    return false;
  }

}