import 'package:app/model/objects/Product.dart';
import 'package:app/model/support/enum/TypeSearch.dart';
import 'package:app/model/support/extensions/StringCapitalization.dart';
import 'package:app/widget/ContainerMenu.dart';
import 'package:app/widget/Header.dart';
import 'package:flutter/material.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';

import '../model/Model.dart';
import '../model/support/Constants.dart';
import '../widget/ButtonMenu.dart';
import '../widget/CircularActionButton.dart';

class SearchProduct extends StatefulWidget {
  const SearchProduct({super.key});

  @override
  State<SearchProduct> createState() => _SearchProductState();
}

class _SearchProductState extends State<SearchProduct> {
  late List<bool> _checkBoxValue;
  late RangeValues _currentRangeValues;
  late ScrollController _scrollController, _scrollControllerCheckbox;
  final PagingController<int, Product> _pagingController = PagingController(firstPageKey: 0);
  TypeSearch? _typeCall;
  String? _value;
  int _page=0, _crossAxisCount= 3;
  late double _size;
  bool _isLastPage=false, _isFabVisible=false, _loadingData=false;




  @override
  void initState(){
    super.initState();
    _scrollControllerCheckbox= ScrollController();
    _scrollController= ScrollController();
    _scrollController.addListener(_scrollListener);
  }

  void _scrollListener(){
    if(_scrollController.position.pixels== _scrollController.position.maxScrollExtent && !_isLastPage && !_loadingData){
      _loadingData=true;
      _loadData();
    }
    if(_scrollController.position.pixels>200){
      setState(() {
        _isFabVisible=true;
      });
    }
    if(_scrollController.position.pixels <200){
      setState(() {
        _isFabVisible=false;
      });
    }

  }

  @override
  void dispose(){
    _scrollController.dispose();
    _scrollControllerCheckbox.dispose();
    _pagingController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    _size= MediaQuery.of(context).size.width;
    if(_size<1500){
      _crossAxisCount= 2;
    }else{
      _crossAxisCount= 3;
    }
   var arguments = ModalRoute.of(context)!.settings.arguments;
   if(arguments!=null && !_isLastPage && !_loadingData) {
     _loadingData=true;
     Map<String, dynamic> map= arguments as Map<String, dynamic>;
     _value= map["value"];
     _typeCall= map["typeCall"];
     if(_typeCall==TypeSearch.searchAdvanced) {
       double start = map["rangeValueStart"];
       double end= map["rangeValueEnd"];
       _currentRangeValues=  RangeValues(start, end);
       _checkBoxValue= map["listBrands"];
     } else{
       _currentRangeValues= const RangeValues(Constants.START_RANGE, Constants.END_RANGE);
       _checkBoxValue= List.generate(10, (index) => false);
     }
     _loadData();
   }
    return Scaffold(
      appBar:  AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        toolbarHeight: 20,
        automaticallyImplyLeading: false,
      ),
      floatingActionButton: _isFabVisible? CircularActionButton(icon: const Icon(Icons.navigation), function: ( ) {
        _scrollController.animateTo(
          0, // Posizione di destinazione (in questo caso, l'inizio)
          duration: const Duration(microseconds: 30), // Durata dell'animazione
          curve: Curves.bounceIn, // Tipo di curva di animazione
        );
      }
      ) : null,
      body: Scrollbar(
        thumbVisibility: true,
        controller: _scrollController,
        child: SingleChildScrollView(
          controller: _scrollController,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Header(size: _size),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  for(String i in Constants.MENU)
                    Padding(
                        padding: const EdgeInsets.symmetric( horizontal: 10.0),
                        child: ButtonMenu(nameButton: i)
                    ),
                ],
              ),
              Stack(
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 50.0, vertical: 50.0),
                    child: buildGrid(),
                  ),
                  ContainerMenu(size: _size)
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget buildGrid(){
    return  Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Column(
          children: [
            const Padding(
              padding: EdgeInsets.only(bottom: 20),
              child: Text("MARCHE",
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700
                ),),
            ),
            Scrollbar(
                thumbVisibility: true,
                controller: _scrollControllerCheckbox,
                child: SizedBox(
                  width: 200,
                  height: 300,
                  child: ListView.builder(
                      controller: _scrollControllerCheckbox,
                      itemCount: _checkBoxValue.length,
                      itemBuilder: (context, index){
                        return ListTile(
                          title: Text(Constants.MARCA[index], style: const  TextStyle(
                            fontSize: 12,
                          ),),
                          leading: Checkbox(
                            value: _checkBoxValue[index],
                            onChanged: (flag){
                              setState(() {
                                _checkBoxValue[index]= !_checkBoxValue[index];
                                //Chiamo il servizio rest che mi effettua la ricerca avanzata
                                Navigator.pushNamed(context, '/search', arguments: {"value": _value, "typeCall": TypeSearch.searchAdvanced,
                                  "listBrands": _checkBoxValue, "rangeValueStart":  _currentRangeValues.start.round(),
                                  "rangeValueEnd": _currentRangeValues.end.round()});
                              });
                            },
                          ),
                        );
                      }
                  ),
                )
            ),
            const Padding(
              padding: EdgeInsets.only(bottom: 20, top: 20),
              child: Text("PREZZO",
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700
                ),),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("${_currentRangeValues.start.round()}€ -",
                  style: const TextStyle(
                  fontWeight: FontWeight.w700
                ),),
                Text(" ${_currentRangeValues.end.round()}€",
                    style: const TextStyle(
                        fontWeight: FontWeight.w700
                    )
                ),
              ],
            ),
            RangeSlider(
                min: 0,
                max: 100,
                divisions: 10,
                activeColor:  Colors.black ,
                values: _currentRangeValues,
                onChangeEnd: (RangeValues values){
                    setState(() {
                        _currentRangeValues= values;
                    });
                    //effettuo la chiamata al servizio rest
                   Navigator.pushNamed(context, '/search', arguments: {"value": _value, "typeCall": TypeSearch.searchAdvanced,
                      "listBrands": _checkBoxValue, "rangeValueStart":  _currentRangeValues.start.round(),
                      "rangeValueEnd": _currentRangeValues.end.round()});
                },
                onChangeStart: (RangeValues values){
                    setState(() {
                      _currentRangeValues= values;
                    });
                    //effettuo la chiamata al servizio rest
                    Navigator.pushNamed(context, '/search', arguments: {"value": _value, "typeCall": TypeSearch.searchAdvanced,
                    "listBrands": _checkBoxValue, "rangeValueStart":  _currentRangeValues.start.round(),
                    "rangeValueEnd": _currentRangeValues.end.round()});
                }, onChanged: (RangeValues value) {  },
            )
          ],
        ),
        Expanded(
          child: PagedGridView<int, Product>(
              pagingController: _pagingController,
              gridDelegate:SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: _crossAxisCount,
                  mainAxisSpacing: 8.0,
                  crossAxisSpacing: 8.0
              ),
              shrinkWrap: true,
              showNewPageProgressIndicatorAsGridChild: false,
              builderDelegate: PagedChildBuilderDelegate<Product>(
                  firstPageProgressIndicatorBuilder: (context){
                    return const Padding(
                      padding:  EdgeInsets.symmetric(vertical: 150),
                      child:  Center(child: SizedBox(width: 100, height: 100 , child: CircularProgressIndicator(),),),
                    );
                  },
                  noItemsFoundIndicatorBuilder: (context){
                    return const Padding(
                      padding: EdgeInsets.symmetric(vertical: 200),
                      child: Center(child:  Text(Constants.MESSAGE_NOT_FOUND_PRODUCT, style: TextStyle( color: Colors.black87, fontSize: 16))),
                    );
                  },
                  itemBuilder: (context, product, index){
                    return SizedBox(
                      height: _size * 0.8,
                      width: _size * 0.75,
                      child: InkWell(
                        hoverColor: Colors.transparent,
                        onTap: () {
                          Navigator.pushNamed(
                              context, '/product', arguments: product);
                        },
                        child: Card(
                          color: Colors.white70,
                          elevation: 0,
                          child: Column(
                            children: [
                              Image.network(
                                "${Constants.PATH_IMAGES}${product.immagine}",
                                width: _size*0.15,
                                height: _size*0.2, fit: BoxFit.fitWidth
                              ),
                              Padding(
                                padding: const EdgeInsets.only(top: 10, bottom: 5),
                                child: Text(
                                  product.nome,
                                  textAlign: TextAlign.right,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                    fontSize: 12
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(bottom: 5),
                                child: Text(
                                  product.marca.capitalizeAll,
                                  style: const TextStyle(
                                      fontSize: 11
                                  ),
                                ),
                              ),
                              Text(
                                "${product.prezzo.toStringAsFixed(2)}€",
                                style: const TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                    );
                  }
              )),
        )
      ],
    );
  }

  Future<void> _loadData( ) async {
    try {
      List<Product> newData= [];
      switch(_typeCall) {
        case TypeSearch.category:
          newData = await Model.sharedInstance.getProductForCategory(
              _value!, pageNumber: _page);
          break;
        case TypeSearch.type:
          newData = await Model.sharedInstance.getProductForType(
              _value!, pageNumber: _page);
          break;
        case TypeSearch.query:
          newData = await Model.sharedInstance.getProductQuery(
              _value!, pageNumber: _page);
          break;
        case TypeSearch.searchAdvanced:
          List<String> marche = [];
          if (_checkBoxValue.contains(true)){
            for (int i = 0; i < _checkBoxValue.length; i++) {
              if (_checkBoxValue[i]) {
                marche.add(Constants.MARCA[i]);
              }
            }
          }
          int minPrice= _currentRangeValues.start.round();
          int maxPrice= _currentRangeValues.end.round();
          newData= await Model.sharedInstance.getRicercaAvanzata(_value!, brands: marche.isEmpty? null: marche, minPrice: minPrice, maxPrice: maxPrice, pageNumber: _page);
          break;
        default:
          break;
      }

      if (newData.isEmpty) {

        _isLastPage=true;
        _pagingController.appendLastPage([]);
      } else {
        _page++;
        _pagingController.appendLastPage(newData);
        _isLastPage= newData.length < 12;
      }
    } catch (error) {
      _pagingController.error = error;
    }
    _loadingData=false;
  }
}
