import 'package:app/model/objects/Product.dart';
import 'package:app/model/objects/ProductInCart.dart';
import 'package:app/model/support/Constants.dart';
import 'package:app/model/support/extensions/StringCapitalization.dart';
import 'package:app/provider/BadgeNotifier.dart';
import 'package:app/provider/CartNotifier.dart';
import 'package:app/provider/UserNotifier.dart';
import 'package:app/widget/Header.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../model/Model.dart';
import '../model/objects/User.dart';
import '../widget/ButtonMenu.dart';
import '../widget/ContainerMenu.dart';

class ProductDescription extends StatefulWidget {
  const ProductDescription({super.key});

  @override
  State<ProductDescription> createState() => _ProductDesciptionState();
}

class _ProductDesciptionState extends State<ProductDescription> {
  late BadgeNotifier _badgeNotifier;
  late CartNotifier _cartNotifier;
  bool _pressed=false;

  @override
  Widget build(BuildContext context) {
    _badgeNotifier= context.watch<BadgeNotifier>();
    _cartNotifier= context.watch<CartNotifier>();
    final userNotifier= context.watch<UserNotifier>();
    double size= MediaQuery.of(context).size.width;
    final Product product= ModalRoute.of(context)!.settings.arguments as Product;
    bool flag= product.quantita<=0 || verifica(product);
    return  Scaffold(
        appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        toolbarHeight: 20,
        automaticallyImplyLeading: false,
        ),
        body: SingleChildScrollView(
    child: Column(
        children: [
        Header(size: size),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            for(String i in Constants.MENU)
              Padding(
                padding: const EdgeInsets.only(left: 10.0, right: 10),
                child: ButtonMenu(nameButton: i)
                ),
              ]
            ),
        Stack(
          children: [
            Padding(
              padding: const EdgeInsets.only(bottom: 50, top:50, left: 50, right: 100),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    width: size* 0.38, //450
                    height: size* 0.28, //350
                    child: Image(
                      image:  NetworkImage('${Constants.PATH_IMAGES}${product.immagine}'),
                    fit: BoxFit.fitHeight,),
                ),
        Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                 Padding(
                  padding: const EdgeInsets.only(left: 20.0, bottom: 5, top: 8),
                  child: Text(
                    product.nome,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 20.0, bottom: 10,),
                  child: Text(
                    product.marca.capitalizeAll,
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                 Padding(
                  padding: const EdgeInsets.only(left: 20.0, bottom: 10, top: 8),
                  child:  Text(
                    product.descrizione,
                    textAlign: TextAlign.justify,
                  ),
                ),
                 Padding(
                  padding: const EdgeInsets.only(top: 150),
                  child: Align(
                    alignment: Alignment.centerRight,
                    child:  Text(
                      "${product.prezzo.toStringAsFixed(2)}€",
                      style: const TextStyle(
                        fontSize: 24,
                        color: Colors.red,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 20),
                  child: Align(
                    alignment: Alignment.centerRight,
                    child: SizedBox(
                      width: 300,
                      height: 40,
                      child: ElevatedButton(
                        onPressed: flag? null: () {
                          if(!_pressed) {
                            _pressed=true;
                            if (!userNotifier.logged) {
                              /***
                                  //Non puoi aggiungere il prodotto al carrello devi prima effettuare il login
                                  showAlertDialog(Constants.MESSAGE_CART_LOGIN);
                               ***/
                              _cartNotifier.addProduct(
                                  ProductInCart(quantity: 1, product: product));
                              _badgeNotifier.add();
                            } else if (userNotifier.logged&&userNotifier.role=='buyer') {
                              addToCart(userNotifier.user!, product.codice);
                            }
                            _pressed=false;
                          }
                        },
                        style:   ButtonStyle(
                            backgroundColor: MaterialStateProperty.resolveWith<Color>((Set<MaterialState> states) {
                                    if(states.contains(MaterialState.pressed)){
                                      return Colors.green;
                                    }
                                    return flag? Colors.grey : Colors.black;
                                  }
                            ),
                            shape: const MaterialStatePropertyAll(RoundedRectangleBorder()),
                            overlayColor: MaterialStateProperty.resolveWith<Color>((Set<MaterialState> states) {
                              if(states.contains(MaterialState.pressed)){
                                return Colors.green;
                              }
                              return Colors.black;
                            }
                          )
                        ),
                        child:    Padding(
                          padding:  const EdgeInsets.only(bottom: 10, top: 10),
                          child:  Text(flag? Constants.NO_PRODUCT :Constants.ADD_TO_CART,
                            textAlign: TextAlign.center,
                            style: const TextStyle(color: Colors.white, fontSize: 16),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),)
        ]
      ),
          ),
          ContainerMenu(size: size)
    ]
      )
    ]
    )
    )
    );

  }


  void addToCart(User user, String code){
    Model.sharedInstance.addToCart(user, code).then((result){
      if(result){
        _badgeNotifier.add();
      }else{
        showAlertDialog(Constants.MESSAGE_CART_ERROR);
      }
    });
  }

 void showAlertDialog(String text){
    showDialog(
        context: context,
        builder: (BuildContext context){
          return AlertDialog(
            title: const Text("ATTENZIONE", style: TextStyle(
              fontWeight: FontWeight.bold
            ),),
            content: Text(text),
            actions: [
              TextButton(
                onPressed: () {
                  // Chiudi il dialog
                  Navigator.of(context).pop();
                },
                child: const Text('OK'),
              ),
            ],

          );
          }
        );
 }

 bool verifica(Product p){
    for(ProductInCart pc in _cartNotifier.productInCart){
      if(pc.product==p){
        return pc.quantity>=p.quantita;
      }
    }
    return false;
 }

}
