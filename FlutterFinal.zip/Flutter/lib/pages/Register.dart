import 'package:app/model/support/Constants.dart';
import 'package:app/model/support/enum/RegisterResult.dart';
import 'package:app/widget/FormEmail.dart';
import 'package:app/widget/FormPassword.dart';
import 'package:app/widget/FormText.dart';
import 'package:email_validator/email_validator.dart';
import 'package:flutter/material.dart';

import '../Icons/custom_icon2_icons.dart';
import '../model/Model.dart';
import '../model/objects/User.dart';

class Register extends StatefulWidget{

  const Register({super.key});



  @override
  State<Register> createState() => _RegisterState();

}

class _RegisterState extends State<Register>{
  final double _size= 400;
  bool _isObscure= true, _isVisible=false;
  late TextEditingController _controllerEmail;
  late TextEditingController _controllerPsw;
  late TextEditingController _controllerPswConf;
  late TextEditingController _controllerName;
  late TextEditingController _controllerLastName;
  late TextEditingController _controllerAddress;
  late TextEditingController _controllerPhone;



  @override
  void initState(){
    super.initState();
    _controllerPsw= TextEditingController();
    _controllerPswConf= TextEditingController();
    _controllerEmail= TextEditingController();
    _controllerName= TextEditingController();
    _controllerLastName= TextEditingController();
    _controllerAddress= TextEditingController();
    _controllerPhone= TextEditingController();
  }

  @override
  void dispose(){
    _controllerPsw.dispose();
    _controllerPswConf.dispose();
    _controllerEmail.dispose();
    _controllerLastName.dispose();
    _controllerName.dispose();
    _controllerAddress.dispose();
    _controllerPhone.dispose();
    super.dispose();
  }

  String? get _errorTextPhone{
    String text= _controllerPhone.value.text;
    if(text.isEmpty) {
      return null;
    }else if(text.isNotEmpty && isValidPhoneNumber(text)){
      return null;
    }
    return "Inserisci un numero di cellulare valido";
  }

  String? get _errorTextPswNotEquals{
    String text= _controllerPsw.value.text;
    String text2= _controllerPswConf.value.text;
    if(text2.isNotEmpty && text != text2) {
      return "Password inserita non è uguale";
    }
    return null;
  }

  bool isValidPhoneNumber(String text){
    if(text.length>=10 && int.tryParse(text)!=null){
      return true;
    }
    return false;
  }


  void update(){
    setState(() {
    });
  }

  @override
  Widget build(BuildContext context) {
   return  SingleChildScrollView(
     child: Center(
       child: Stack(
         alignment: AlignmentDirectional.center,
         children: [
           Padding(
           padding: const EdgeInsets.only(top: 60),
           child: Column(
             children: [
               Padding(
                 padding: const EdgeInsets.only(bottom: 30),
                 child: SizedBox(
                   width: _size,
                   child: FormText(controller: _controllerName,  label: 'Nome',)
                 ),
               ),
               Padding(
                 padding: const EdgeInsets.only(bottom: 30),
                 child: SizedBox(
                   width: _size,
                   child: FormText(controller: _controllerLastName, label: 'Cognome',)
                 ),
               ),
               Padding(
                 padding: const EdgeInsets.only(bottom: 30),
                 child: SizedBox(
                   width: _size,
                   child: FormEmail(controllerEmail: _controllerEmail,)
                 ),
               ),
               Padding(
                 padding: const EdgeInsets.only(bottom: 30),
                 child: SizedBox(
                     width: _size,
                     child: FormText(controller: _controllerAddress, label: 'Indirizzo',)
                 ),
               ),
               Padding(
                 padding: const EdgeInsets.only(bottom: 30),
                 child: SizedBox(
                     width: _size,
                     child: TextField(
                       controller: _controllerPhone,
                       onChanged: (_) => setState(() { }),
                       onSubmitted:(_) => setState(() { }),
                       cursorColor: Colors.black,
                       cursorHeight: 20,
                       cursorWidth: 1,
                       decoration:  InputDecoration(
                           labelText: 'Telefono',
                         focusedBorder: const UnderlineInputBorder(
                             borderSide: BorderSide( color:  Colors.black)),
                         labelStyle: const TextStyle(fontStyle: FontStyle.italic, color: Colors.black),
                         errorText: _errorTextPhone,
                       ),
                     )
                 ),
               ),
               Padding(
                 padding: const EdgeInsets.only(bottom: 30),
                 child: SizedBox(
                   width: _size,
                   child: FormPassword(controllerPsw: _controllerPsw , label: "Password", callback: update)
                 ),
               ),
               Padding(
                 padding: const EdgeInsets.only(bottom: 30),
                 child: SizedBox(
                   width: _size,
                   child:TextField(
                     controller: _controllerPswConf,
                     cursorColor: Colors.black,
                     cursorHeight: 20,
                     cursorWidth: 1,
                     obscureText: _isObscure,
                     decoration: InputDecoration(
                       focusedBorder: const UnderlineInputBorder(
                           borderSide: BorderSide( color:  Colors.black)
                       ),
                       labelText: "Conferma password",
                       labelStyle: const TextStyle(fontStyle: FontStyle.italic, color: Colors.black),
                       suffixIcon: !_isObscure?  IconButton(
                         icon: const Icon(CustomIcon2.eye_off_1, size: 20), onPressed: (){
                         setState(() {
                           _isObscure=!_isObscure;
                         });
                       },) : IconButton(
                         icon: const Icon(CustomIcon2.eye_3, size: 20,),
                         onPressed: (){
                           setState(() {
                             _isObscure=!_isObscure;
                           });
                         },
                       ),
                       errorText: _errorTextPswNotEquals,
                     ),
                     onChanged: (_) => setState(() { }),
                     onSubmitted:(_) => setState(() { }),
                   ),
                 ),
               ),
               Padding(
                 padding: const EdgeInsets.only(top: 30, bottom: 20),
                 child: SizedBox(
                   width: _size,
                   child: ElevatedButton(
                     onPressed: (){
                        signUp();
                     },
                     style: const ButtonStyle(
                         backgroundColor: MaterialStatePropertyAll(Colors.black),
                         shape: MaterialStatePropertyAll(RoundedRectangleBorder()),
                         overlayColor: MaterialStatePropertyAll(Colors.black)

                     ),
                     child:  const Padding(
                       padding:  EdgeInsets.only(bottom: 10, top: 10),
                       child:  Text("CREA IL MIO ACCOUNT",
                         textAlign: TextAlign.center,
                         style: TextStyle(color: Colors.white, fontSize: 18),
                       ),
                     ),
                   ),
                 ),
               )
             ],
           ),
         ),
           Visibility(
               visible: _isVisible,
               child: const SizedBox(width:100, height: 100, child: const CircularProgressIndicator()))
         ]
       ),
     ),
   );
  }


  Future<void> signUp() async {
    setState(() {
      _isVisible= !_isVisible;
    });
    String nome= _controllerName.value.text;
    String cognome= _controllerLastName.value.text;
    String email= _controllerEmail.value.text;
    String password= _controllerPsw.value.text;
    String passwordConf= _controllerPswConf.value.text;
    String indirizzo= _controllerAddress.value.text;
    String telefono= _controllerPhone.value.text;

    if(nome.isEmpty || cognome.isEmpty || email.isEmpty || !EmailValidator.validate(email) || password.isEmpty
        || passwordConf.isEmpty || password!=passwordConf || indirizzo.isEmpty || telefono.isEmpty){
        showSnackBar(Constants.ERROR_NOT_COMPILE_FORM, false);

    }else {
      User user = User(nome: nome,
          cognome: cognome,
          email: email,
          indirizzo: indirizzo,
          telefono: telefono);
      RegisterResult result = await Model.sharedInstance.signUp(user, password);
      if (result == RegisterResult.signUp) {
        _controllerPswConf.clear();
        _controllerPsw.clear();
        _controllerEmail.clear();
        _controllerLastName.clear();
        _controllerName.clear();
        _controllerPhone.clear();
        _controllerAddress.clear();
        showSnackBar(Constants.SIGNUP, true);
      } else if (result == RegisterResult.errorEmailExist) {
        showSnackBar(Constants.ERROR_EMAIL_EXSIST, false);
      } else {
        showSnackBar(Constants.SIGNUP_FAILED, false);
      }
    }
    setState(() {
      _isVisible=!_isVisible;
    });
  }


  void showSnackBar(String text, bool registrationSuccess){
    var snackBar =   SnackBar(
      action: SnackBarAction(label: "Chiudi",
          onPressed: () {
            ScaffoldMessenger.of(context).hideCurrentSnackBar();
          }),
      content: Text(text),
      dismissDirection: DismissDirection.up,
      behavior: SnackBarBehavior.floating,
      elevation: 15.0,
      backgroundColor: registrationSuccess? Colors.green: Colors.red,
      duration: const Duration(seconds: 10),
      padding: const EdgeInsets.all(10),
    );
    ScaffoldMessenger.of(context).showSnackBar(snackBar);

  }



}
