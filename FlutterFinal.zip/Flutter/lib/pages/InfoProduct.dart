import 'package:app/model/objects/Product.dart';
import 'package:app/model/support/Constants.dart';
import 'package:app/model/support/extensions/StringCapitalization.dart';
import 'package:app/provider/UserNotifier.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../model/Model.dart';

class InfoProduct extends StatefulWidget {

  const InfoProduct({super.key});

  @override
  State<InfoProduct> createState() => _InfoProductState();
}

class _InfoProductState extends State<InfoProduct> {
  Product? product;
  late UserNotifier _userNotifier;
  late TextEditingController _controller;
  int quantityAdd=0;

  @override
  void initState(){
    super.initState();
    _controller= TextEditingController();

  }


  @override
  Widget build(BuildContext context) {
    _userNotifier= context.watch<UserNotifier>();
    if(_userNotifier.logged&&_userNotifier.role=='admin') {
      product ??= ModalRoute
          .of(context)!
          .settings
          .arguments as Product;
      _controller.text = '${product?.prezzo.toStringAsFixed(2)}€';
    }
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        toolbarHeight: 50,
      ),
      body:
      _userNotifier.logged&&_userNotifier.role=='admin'?
      SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 50, horizontal: 100),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Image.network("${Constants.PATH_IMAGES}${product!.immagine}", width: 300,height: 300,),
              Expanded(child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 100),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Padding(
                      padding: EdgeInsets.only(top:30,),
                      child: Text(
                        "NOME PRODOTTO",
                        style: TextStyle(
                            fontWeight: FontWeight.w500,
                            fontSize: 20.0,
                            fontStyle: FontStyle.italic
                        ),
                      ),
                    ),
                    TextField(
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.zero,
                        ),),
                      enabled: false,
                      controller: TextEditingController(text:product!.nome.capitalizeAll),
                      style: const TextStyle(
                          fontSize: 14.0,
                          color: Colors.black
                      ),
                    ),
                    const Padding(
                      padding: EdgeInsets.only(top:30,),
                      child: Text(
                        "CODICE",
                        style: TextStyle(
                            fontWeight: FontWeight.w500,
                            fontSize: 20.0,
                            fontStyle: FontStyle.italic
                        ),
                      ),
                    ),
                    TextField(
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.zero,
                        ),),
                      enabled: false,
                      controller: TextEditingController(text:product!.codice.toUpperCase()),
                      style: const TextStyle(
                          fontSize: 14.0,
                          color: Colors.black
                      ),),
                    const Padding(
                      padding: EdgeInsets.only(top:30,),
                      child: Text(
                        "CATEGORIA",
                        style: TextStyle(
                            fontWeight: FontWeight.w500,
                            fontSize: 20.0,
                            fontStyle: FontStyle.italic
                        ),
                      ),
                    ),
                    TextField(
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.zero,
                        ),),
                      enabled: false,
                      controller: TextEditingController(text:product!.categoria.capitalize),
                      style: const TextStyle(
                          fontSize: 14.0,
                          color: Colors.black
                      ),),
                    const Padding(
                      padding: EdgeInsets.only(top:30,),
                      child: Text(
                        "TIPO",
                        style: TextStyle(
                            fontWeight: FontWeight.w500,
                            fontSize: 20.0,
                            fontStyle: FontStyle.italic
                        ),
                      ),
                    ),
                    TextField(
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.zero,
                        ),),
                      enabled: false,
                      controller: TextEditingController(text:product!.tipo.capitalize),
                      style: const TextStyle(
                          fontSize: 14.0,
                          color: Colors.black
                      ),),
                    const Padding(
                      padding: EdgeInsets.only(top:30,),
                      child: Text(
                        "MARCA",
                        style: TextStyle(
                            fontWeight: FontWeight.w500,
                            fontSize: 20.0,
                            fontStyle: FontStyle.italic
                        ),
                      ),
                    ),
                    TextField(
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.zero,
                        ),),
                      enabled: false,
                      controller: TextEditingController(text:product!.marca.capitalizeAll),
                      style: const TextStyle(
                          fontSize: 14.0,
                          color: Colors.black
                      ),),
                    const Padding(
                      padding: EdgeInsets.only(top:30,),
                      child: Text(
                        "DESCRIZIONE",
                        style: TextStyle(
                            fontWeight: FontWeight.w500,
                            fontSize: 20.0,
                            fontStyle: FontStyle.italic
                        ),
                      ),
                    ),
                    TextField(
                      maxLines: 10,
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.zero,
                        ),),
                      enabled: false,
                      controller: TextEditingController(text:product!.descrizione.capitalize),
                      style: const TextStyle(
                          fontSize: 14.0,
                          color: Colors.black
                      ),),
                    const Padding(
                      padding: EdgeInsets.only(top:30,),
                      child: Text(
                        "PEZZI DISPONIBILI",
                        style: TextStyle(
                            fontWeight: FontWeight.w500,
                            fontSize: 20.0,
                            fontStyle: FontStyle.italic
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 500,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          SizedBox(
                            width: 200,
                            child: TextField(
                              enabled: false,
                              decoration: const InputDecoration(
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.zero,
                                ),),
                              controller: TextEditingController(text:product!.quantita.toString()),
                              style: const TextStyle(
                                  fontSize: 14.0,
                                  color: Colors.black
                              ),),
                          ),
                          SizedBox(
                            width: 300,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                IconButton(
                                  icon: const Icon(Icons.add, size: 12),
                                  onPressed: (){
                                    setState(() {
                                      quantityAdd++;
                                    });
                                  },
                                ),
                                SizedBox(
                                  width: 70,
                                  child: TextField(
                                    textAlign: TextAlign.center,
                                    decoration: const InputDecoration(
                                        border: OutlineInputBorder(
                                          borderRadius: BorderRadius.zero,
                                        ),),
                                    controller: TextEditingController(text:quantityAdd.toString()),
                                    style: const TextStyle(
                                        fontSize: 14.0,
                                        color: Colors.black
                                    ),
                                    onSubmitted: (String value){
                                      setState(() {
                                        quantityAdd= int.parse(value);
                                      });
                                    },
                                  )
                                ),
                                IconButton(
                                  alignment: Alignment.topCenter,
                                  icon: const Icon(Icons.minimize, size:14),
                                  onPressed: quantityAdd<=0? null : () {
                                    setState(() {
                                      quantityAdd--;
                                    });
                                  }, )
                              ],
                            ),
                          )
                        ],
                      ),
                    ),
                    const Padding(
                      padding: EdgeInsets.only(top:30,),
                      child: Text(
                        "PREZZO",
                        style: TextStyle(
                            fontWeight: FontWeight.w500,
                            fontSize: 20.0,
                            fontStyle: FontStyle.italic
                        ),
                      ),
                    ),
                    TextField(
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.zero,
                        ),),
                      controller: _controller, //TextEditingController(text:'${product.prezzo.toStringAsFixed(2)}€'),
                      style: const TextStyle(
                          fontSize: 14.0,
                          color: Colors.black
                      ),),
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 50, ),
                      child: Center(
                        child: SizedBox(
                          width: 200,
                          child: ElevatedButton(
                            onPressed: ( ){
                              updateProduct(product!.codice, quantityAdd, double.parse(_controller.text.substring(0, _controller.text.toString().length-1)));
                            },
                            style: const ButtonStyle(
                                backgroundColor: MaterialStatePropertyAll(Colors.green),
                                shape: MaterialStatePropertyAll(RoundedRectangleBorder()),
                                overlayColor: MaterialStatePropertyAll(Colors.green)

                            ),
                            child:  const Padding(
                              padding:  EdgeInsets.only(bottom: 10, top: 10),
                              child:  Text("SALVA",
                                textAlign: TextAlign.center,
                                style: TextStyle(color: Colors.white, fontSize: 18),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ))
            ],
          ),
        ),
      ) : const SizedBox.shrink()
    );
  }


  void updateProduct(String codeProduct, int quantity, double price) {
    if(quantity<0){
      showAlertDialog(Constants.MESSAGE_QUANTITY_ERROR);
    }else if(price<=0){
      showAlertDialog(Constants.MESSAGE_PRICE_ERROR);
    }else{
      Model.sharedInstance.updateProduct(codeProduct, quantity, price).then((value) {
        if(value!=null) {
          showAlertDialog(Constants.MESSAGE_UPDATE_SUCCESS);
          setState(() {
            product = value;
            quantityAdd=0;
          });
        }else{
          showAlertDialog(Constants.MESSAGE_UPDATE_ERROR);
        }
      });
    }
  }

  void showAlertDialog(String text){
    showDialog(
        context: context,
        builder: (BuildContext context){
          return AlertDialog(
            title: const Text("ATTENZIONE", style: TextStyle(
                fontWeight: FontWeight.bold
            ),),
            content: Text(text),
            actions: [
              TextButton(
                onPressed: () {
                  // Chiudi il dialog
                  Navigator.of(context).pop();
                },
                child: const Text('OK'),
              ),
            ],
          );
        }
    );
  }

}
