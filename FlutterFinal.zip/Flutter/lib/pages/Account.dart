import 'package:app/Icons/custom_icon2_icons.dart';
import 'package:app/Icons/icons_arrows_icons.dart';
import 'package:app/Icons/my_flutter_app_icons.dart';
import 'package:app/model/support/extensions/StringCapitalization.dart';
import 'package:app/provider/BadgeNotifier.dart';
import 'package:app/provider/CartNotifier.dart';
import 'package:app/provider/UserNotifier.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../model/Model.dart';
import '../model/objects/Purchase.dart';
import '../model/objects/User.dart';
import '../model/support/Constants.dart';
import '../widget/ButtonMenu.dart';
import '../widget/ContainerMenu.dart';
import '../widget/Header.dart';
import 'MyHomePage.dart';

class Account extends StatefulWidget {
  const Account({super.key});

  @override
  State<Account> createState() => _AccountState();
}

class _AccountState extends State<Account> {
  late double _size;
  late ScrollController _controller;
  bool _viewHomePage= true;
  late UserNotifier _userNotifier;
  late BadgeNotifier _badgeNotifier;
  late CartNotifier _cartNotifier;
  List<Purchase> _acquisti= [];
  late User _user;
  int _page=0;
  bool _lastPage=false, flag=false;

  @override
  void initState(){
    super.initState();
    _controller=  ScrollController();
    getInfo();
  }

  @override
  void dispose(){
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size.width;
    _userNotifier= context.watch<UserNotifier>();
    _badgeNotifier= context.watch<BadgeNotifier>();
    _cartNotifier= context.watch<CartNotifier>();
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        toolbarHeight: 20,
        automaticallyImplyLeading: false,
      ),
      body: Scrollbar(
        thumbVisibility: true,
        controller: _controller,
        child: SingleChildScrollView(
          controller: _controller,
          child: Column(
            children: [
              Header(size:_size),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  for(String i in Constants.MENU)
                    Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10.0),
                        child: ButtonMenu(nameButton: i)
                    )
                ],
              ),
             !flag? const SizedBox.shrink()
             : Stack(
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 50, horizontal: 100),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Column(
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(4.0),
                              child: SizedBox(
                                width: 250,
                                height: 50,
                                child: ElevatedButton(
                                    style:    ButtonStyle(
                                        backgroundColor:  MaterialStateProperty.resolveWith<Color?>((Set<MaterialState> states) {
                                          if(states.contains(MaterialState.hovered) || states.contains(MaterialState.focused)){
                                            return Colors.deepOrange[300];
                                          }
                                          return Colors.black;
                                        }
                                        ),
                                        shape: const MaterialStatePropertyAll(RoundedRectangleBorder()),
                                        overlayColor:MaterialStateProperty.resolveWith<Color?>((Set<MaterialState> states) {
                                          if(states.contains(MaterialState.hovered) || states.contains(MaterialState.focused)){
                                            return Colors.deepOrange[300];
                                          }
                                          return Colors.black;
                                        }
                                        ),
                                        alignment: Alignment.center
                                    ),
                                    onPressed: (){
                                      setState(() {
                                        _viewHomePage=true;
                                      });
                                    },
                                    child: const Padding(
                                      padding: EdgeInsets.only(right: 10),
                                      child: Row(
                                        children: [
                                          Icon(MyFlutterApp.home_1, color: Colors.white, size: 15),
                                          Padding(
                                            padding: EdgeInsets.only(left: 10.0),
                                            child: Text("IL MIO PROFILO",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(color: Colors.white, fontSize: 16),),
                                          )
                                        ],
                                      ),
                                    )
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(4.0),
                              child: SizedBox(
                                width: 250,
                                height: 50,
                                child: ElevatedButton(
                                  style:    ButtonStyle(
                                      backgroundColor:  MaterialStateProperty.resolveWith<Color?>((Set<MaterialState> states) {
                                        if(states.contains(MaterialState.hovered) || states.contains(MaterialState.focused)){
                                          return Colors.deepOrange[300];
                                        }
                                        return Colors.black;
                                      }
                                      ),
                                      shape: const MaterialStatePropertyAll(RoundedRectangleBorder()),
                                      overlayColor:MaterialStateProperty.resolveWith<Color?>((Set<MaterialState> states) {
                                        if(states.contains(MaterialState.hovered) || states.contains(MaterialState.focused)){
                                          return Colors.deepOrange[300];
                                        }
                                        return Colors.black;
                                      }
                                      ),
                                      alignment: Alignment.center
                                  ),
                                    onPressed: (){
                                    if(_acquisti.isEmpty) {
                                      getOrdini();
                                    }else{
                                      setState(() {
                                        _viewHomePage=false;
                                      });
                                    }
                                    },
                                    child: const Padding(
                                      padding: EdgeInsets.only(right: 10),
                                      child: Row(
                                        children: [
                                          Icon(MyFlutterApp.local_mall, color: Colors.white, size: 15),
                                          Padding(
                                            padding: EdgeInsets.only(left: 10.0),
                                            child: Text("I MIEI ORDINI",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(color: Colors.white, fontSize: 16),),
                                          )
                                        ],
                                      ),
                                    )
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(4.0),
                              child: SizedBox(
                                width: 250,
                                height: 50,
                                child: ElevatedButton(
                                    style:   ButtonStyle(
                                        backgroundColor:  MaterialStateProperty.resolveWith<Color?>((Set<MaterialState> states) {
                                              if(states.contains(MaterialState.hovered) || states.contains(MaterialState.focused)){
                                                return Colors.deepOrange[300];
                                              }
                                              return Colors.black;
                                            }
                                        ),
                                        shape: const MaterialStatePropertyAll(RoundedRectangleBorder()),
                                        overlayColor:MaterialStateProperty.resolveWith<Color?>((Set<MaterialState> states) {
                                          if(states.contains(MaterialState.hovered) || states.contains(MaterialState.focused)){
                                            return Colors.deepOrange[300];
                                          }
                                          return Colors.black;
                                        }
                                        ),
                                        alignment: Alignment.center
                                    ),
                                    onPressed: (){
                                      signOut(context);
                                    },
                                    child: const Padding(
                                      padding: EdgeInsets.only(right: 10),
                                      child: Row(
                                        children: [
                                          Icon(MyFlutterApp.logout_1, color: Colors.white, size: 15),
                                          Padding(
                                            padding: EdgeInsets.only(left: 10.0),
                                            child: Text("ESCI",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(color: Colors.white, fontSize: 16),),
                                          )
                                        ],
                                      ),
                                    )
                                ),
                              ),
                            )
                          ],
                        ),
                        _viewHomePage? HomePage() : Purchases()

                      ],
                    ),
                  ),
                  ContainerMenu(size: _size)
                ],
              )
            ],
          ),
        ),
      ),
    );
  }


  Widget HomePage(){
    return   Expanded(
      child: Padding(
        padding: const EdgeInsets.only(left: 10, bottom: 30),
        child: Container(
          //width: 20,
          //height: MediaQuery.of(context).size.height,
          decoration: BoxDecoration(
            color: Colors.grey[50],
            border: Border.all(
              color: Colors.black, // Colore del bordo
              width: 1.0,          // Larghezza del bordo
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 100, vertical: 50),
            child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
             const Text(
                "Nome",
                style: TextStyle(
                  fontWeight: FontWeight.w500,
                  fontSize: 20.0,
                  fontStyle: FontStyle.italic
                ),
              ),
              TextField(
                enabled: false,
                controller: TextEditingController(text:_user?.nome.capitalizeAll),
                style: const TextStyle(
                  fontSize: 14.0,
                  color: Colors.black
                ),
              ),
              const Padding(
                padding: EdgeInsets.only(top:30,),
                child: Text(
                  "Cognome",
                  style: TextStyle(
                      fontWeight: FontWeight.w500,
                      fontSize: 20.0,
                      fontStyle: FontStyle.italic
                  ),
                ),
              ),
              TextField(
                enabled: false,
                controller: TextEditingController(text:_user?.cognome.capitalizeAll),
                style: const TextStyle(
                    fontSize: 14.0,
                    color: Colors.black
                ),
              ),
              const Padding(
                padding: EdgeInsets.only(top:30,),
                child: Text(
                  "Email",
                  style: TextStyle(
                      fontWeight: FontWeight.w500,
                      fontSize: 20.0,
                      fontStyle: FontStyle.italic
                  ),
                ),
              ),
              TextField(
                enabled: false,
                controller: TextEditingController(text:_user?.email),
                style: const TextStyle(
                    fontSize: 14.0,
                    color: Colors.black
                ),
              ),
              const Padding(
                padding: EdgeInsets.only(top:30,),
                child: Text(
                  "Indirizzo",
                  style: TextStyle(
                      fontWeight: FontWeight.w500,
                      fontSize: 20.0,
                      fontStyle: FontStyle.italic
                  ),
                ),
              ),
              TextField(
                enabled: false,
                controller: TextEditingController(text:_user?.indirizzo),
                style: const TextStyle(
                    fontSize: 14.0,
                    color: Colors.black
                ),
              ),
              const Padding(
                padding: EdgeInsets.only(top:30,),
                child: Text(
                  "Telefono",
                  style: TextStyle(
                      fontWeight: FontWeight.w500,
                      fontSize: 20.0,
                      fontStyle: FontStyle.italic
                  ),
                ),
              ),
              TextField(
                enabled: false,
                controller: TextEditingController(text:_user?.telefono),
                style: const TextStyle(
                    fontSize: 14.0,
                    color: Colors.black
                ),
              ),

            ],
             ),
          ),
        ),
      ),
    );
  }

  void getOrdini(){
    Model.sharedInstance.getAllPurchases(pageNumber: _page).then((result) {
      setState(() {
        if(result.length<Constants.SIZE_PAGE){
          _lastPage=true;
        }
        _acquisti.addAll(result);
        _viewHomePage=false;
      });
    });
  }

  Widget Purchases(){
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.only(left: 10, bottom: 30),
        child: Container(
          width: 20,
          height: 150.0* Constants.SIZE_PAGE,//MediaQuery.of(context).size.height,
          decoration: BoxDecoration(
            color: Colors.grey[50],
            border: Border.all(
              color: Colors.black, // Colore del bordo
              width: 1.0,          // Larghezza del bordo
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 100, vertical: 20),
            child: Column(
              children: [
                for(Purchase purchase in sublistAcquisti())
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        border: Border.all(
                          color: Colors.black,
                          width: 0.5,
                        ),),
                      child: ListTile(
                        title: Text("ORDINE N. ${purchase.numeroOrdine.toString()
                            .padLeft(8, '0')}"),
                        subtitle: Text('${purchase.data!.day.toString()}-${purchase
                            .data!.month.toString()}-${purchase.data!.year
                            .toString()}'),
                        trailing: Text("${purchase.prezzo.toStringAsFixed(2)}€"),
                        shape: const RoundedRectangleBorder(),
                        contentPadding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 10),
                        titleTextStyle: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w600
                        ),
                        leadingAndTrailingTextStyle: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w500
                        ),
                      ),
                    ),
                  ),
               Padding(
                 padding: const EdgeInsets.symmetric(vertical: 50),
                 child: Row(
                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                   children: [
                     Visibility(
                       visible: _acquisti.isNotEmpty,
                       child: IconButton(
                           onPressed: _page==0? null: (){
                             //torno alla pagina precedente
                             _controller.animateTo(0,
                                 duration:  const Duration(microseconds: 30),
                                 curve: Curves.bounceIn);
                             setState(() {
                               if(_lastPage){
                                 _lastPage=false;
                               }
                               _page--;
                             });
                           },
                           icon: const Icon(IconsArrows.angle_double_left)),
                     ),
                     Visibility(
                       visible: _acquisti.isNotEmpty,
                       child: IconButton(
                           onPressed:  _lastPage? null : (){
                             //vado alla pagina succsessiva
                             _page++;
                             if(_page*Constants.SIZE_PAGE>_acquisti.length-1){
                               getOrdini();
                             }else{
                               setState(() {
                                 if(_acquisti.length-_page*Constants.SIZE_PAGE<Constants.SIZE_PAGE){
                                   _lastPage=true;
                                 }
                               });
                             }
                             _controller.animateTo(0,
                                 duration:  const Duration(microseconds: 30),
                                 curve: Curves.bounceIn);
                           },
                           icon: const Icon(IconsArrows.angle_double_right)),
                     ),
                   ],
                 ),
               )
              ],
            ),
          ),
        ),
      ),
    );
  }

  List<Purchase> sublistAcquisti(){
    if(_page*Constants.SIZE_PAGE+Constants.SIZE_PAGE>_acquisti.length){
      return _acquisti.sublist(_page*Constants.SIZE_PAGE, _acquisti.length);
    }
    return _acquisti.sublist(_page*Constants.SIZE_PAGE, _page*Constants.SIZE_PAGE+Constants.SIZE_PAGE);
  }

  void signOut(BuildContext context){
    Model.sharedInstance.logout().then((result) {
        if(result){
          _userNotifier.logout();
          _badgeNotifier.clear();
          _cartNotifier.removeAllProduct();
           Navigator.pushAndRemoveUntil(context, MaterialPageRoute(
               builder: (context) => const MyHomePage()), (route) => false);
        }
    });
  }

  void getInfo() async{
    Model.sharedInstance.getUserInfo().then((result) {
      if(result!=null){
        _user= result;
        setState(() {
          flag=true;
        });
      }else{
        Navigator.popAndPushNamed(context, '/account');
      }
    });

  }
}
