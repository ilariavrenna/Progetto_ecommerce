import 'package:app/model/objects/Product.dart';
import 'package:app/provider/UserNotifier.dart';
import 'package:app/widget/FormText.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../model/Model.dart';
import '../model/support/Constants.dart';

class AddNewProduct extends StatefulWidget {
  const AddNewProduct({super.key});

  @override
  State<AddNewProduct> createState() => _AddNewProductState();
}

class _AddNewProductState extends State<AddNewProduct> {
  late TextEditingController _controllerNameProduct;
  late TextEditingController _controllerCodeProduct;
  late TextEditingController _controllerDescrizione;
  late TextEditingController _controllerQuantity;
  late TextEditingController _controllerPrice;
  late TextEditingController _controllerNameImage;
  late UserNotifier _userNotifier;
  String? selectedOptionCategory;
  String? selectedOptionType;
  String? selectedOptionBrand;




  @override
  void initState(){
    super.initState();
    _controllerCodeProduct= TextEditingController();
    _controllerDescrizione= TextEditingController();
    _controllerNameProduct= TextEditingController();
    _controllerQuantity= TextEditingController();
    _controllerPrice= TextEditingController();
    _controllerNameImage= TextEditingController();
  }

  @override
  void dispose(){
    _controllerCodeProduct.dispose();
    _controllerDescrizione.dispose();
    _controllerNameProduct.dispose();
    _controllerPrice.dispose();
    _controllerQuantity.dispose();
    _controllerNameImage.dispose();
    super.dispose();
  }



  @override
  Widget build(BuildContext context) {
    _userNotifier= context.watch<UserNotifier>();
      return Scaffold(
        appBar: AppBar(
          backgroundColor: Theme.of(context).colorScheme.inversePrimary,
          toolbarHeight: 50,
        ),
        body:
        _userNotifier.logged&&_userNotifier.role=='admin'?
        SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 50, horizontal: 100),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 100),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Padding(
                        padding: EdgeInsets.only(top:30,),
                        child: Text(
                          "NOME PRODOTTO",
                          style: TextStyle(
                              fontWeight: FontWeight.w500,
                              fontSize: 20.0,
                              fontStyle: FontStyle.italic
                          ),
                        ),
                      ),
                      TextField(
                        decoration: const InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.zero,
                          ),),
                        controller: _controllerNameProduct,
                        style: const TextStyle(
                            fontSize: 14.0,
                            color: Colors.black
                        ),
                      ),
                      const Padding(
                        padding: EdgeInsets.only(top:30,),
                        child: Text(
                          "CODICE",
                          style: TextStyle(
                              fontWeight: FontWeight.w500,
                              fontSize: 20.0,
                              fontStyle: FontStyle.italic
                          ),
                        ),
                      ),
                      TextField(
                        decoration: const InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.zero,
                          ),),
                        controller: _controllerCodeProduct,
                        style: const TextStyle(
                            fontSize: 14.0,
                            color: Colors.black
                        ),),
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 20),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Padding(
                                  padding: EdgeInsets.only( bottom: 20),
                                  child: Text(
                                    "CATEGORIA",
                                    style: TextStyle(
                                        fontWeight: FontWeight.w500,
                                        fontSize: 20.0,
                                        fontStyle: FontStyle.italic
                                    ),
                                  ),
                                ),
                                DropdownButton<String>(
                                  value: selectedOptionCategory,
                                  items: Constants.MENU.map((String option) {
                                    return DropdownMenuItem<String>(
                                      value: option,
                                      child: Text(option.toUpperCase()),
                                    );
                                  }).toList(),
                                  onChanged: (String? newValue) {
                                    setState(() {
                                      print(newValue);
                                      selectedOptionCategory = newValue;
                                      print(selectedOptionCategory);
                                    });
                                  },
                                  hint: const Text('Seleziona un\'opzione'),
                                ),
                              ],
                            ),
                           Column(
                             children: [
                               const Padding(
                                 padding: EdgeInsets.only( bottom: 20),
                                 child: Text(
                                   "TIPO",
                                   style: TextStyle(
                                       fontWeight: FontWeight.w500,
                                       fontSize: 20.0,
                                       fontStyle: FontStyle.italic
                                   ),
                                 ),
                               ),
                               DropdownButton<String>(
                                 value: selectedOptionType,
                                 items: Constants.MAP_MENU[selectedOptionCategory]?.map((String option) {
                                   return DropdownMenuItem<String>(
                                     value: option,
                                     child: Text(option.toUpperCase()),
                                   );
                                 }).toList(),
                                 onChanged: (String? newValue) {
                                   setState(() {
                                     selectedOptionType = newValue;
                                   });
                                 },
                                 hint: const Text('Seleziona un\'opzione'),
                               ),
                             ],
                           ),
                            Column(
                              children: [
                                const Padding(
                                  padding: EdgeInsets.only( bottom: 20),
                                  child: Text(
                                    "MARCA",
                                    style: TextStyle(
                                        fontWeight: FontWeight.w500,
                                        fontSize: 20.0,
                                        fontStyle: FontStyle.italic
                                    ),
                                  ),
                                ),
                                DropdownButton<String>(
                                  value: selectedOptionBrand,
                                  items: Constants.MARCA.map((String option) {
                                    return DropdownMenuItem<String>(
                                      value: option,
                                      child: Text(option.toUpperCase()),
                                    );
                                  }).toList(),
                                  onChanged: (String? newValue) {
                                    setState(() {
                                      selectedOptionBrand = newValue;
                                    });
                                  },
                                  hint: const Text('Seleziona un\'opzione'),
                                ),
                              ],
                            )
                          ],
                        ),
                      ),
                      const Padding(
                        padding: EdgeInsets.only(top:30,),
                        child: Text(
                          "DESCRIZIONE",
                          style: TextStyle(
                              fontWeight: FontWeight.w500,
                              fontSize: 20.0,
                              fontStyle: FontStyle.italic
                          ),
                        ),
                      ),
                      TextField(
                        maxLines: 10,
                        decoration: const InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.zero,
                          ),),
                        controller: _controllerDescrizione,
                        style: const TextStyle(
                            fontSize: 14.0,
                            color: Colors.black
                        ),),
                      const Padding(
                        padding: EdgeInsets.only(top:30,),
                        child: Text(
                          "PEZZI DISPONIBILI",
                          style: TextStyle(
                              fontWeight: FontWeight.w500,
                              fontSize: 20.0,
                              fontStyle: FontStyle.italic
                          ),
                        ),
                      ),
                      TextField(
                        inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                        decoration: const InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.zero,
                          ),),
                        controller: _controllerQuantity,
                        style: const TextStyle(
                            fontSize: 14.0,
                            color: Colors.black
                        ),),
                      const Padding(
                        padding: EdgeInsets.only(top:30,),
                        child: Text(
                          "PREZZO",
                          style: TextStyle(
                              fontWeight: FontWeight.w500,
                              fontSize: 20.0,
                              fontStyle: FontStyle.italic
                          ),
                        ),
                      ),
                      TextField(
                        inputFormatters: <TextInputFormatter>[
                      FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d{0,2}'))],
                        decoration: const InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.zero,
                          ),),
                        controller: _controllerPrice, //TextEditingController(text:'${product.prezzo.toStringAsFixed(2)}€'),
                        style: const TextStyle(
                            fontSize: 14.0,
                            color: Colors.black
                        ),),
                      const Padding(
                        padding: EdgeInsets.only(top:30,),
                        child: Text(
                          "IMMAGINE",
                          style: TextStyle(
                              fontWeight: FontWeight.w500,
                              fontSize: 20.0,
                              fontStyle: FontStyle.italic
                          ),
                        ),
                      ),
                      TextField(
                        decoration: const InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.zero,
                          ),),
                        controller: _controllerNameImage,
                        style: const TextStyle(
                            fontSize: 14.0,
                            color: Colors.black
                        ),),
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 50, ),
                        child: Center(
                          child: SizedBox(
                            width: 200,
                            child: ElevatedButton(
                              onPressed: ( ){

                                addNewProduct();

                              },
                              style: const ButtonStyle(
                                  backgroundColor: MaterialStatePropertyAll(Colors.green),
                                  shape: MaterialStatePropertyAll(RoundedRectangleBorder()),
                                  overlayColor: MaterialStatePropertyAll(Colors.green)

                              ),
                              child:  const Padding(
                                padding:  EdgeInsets.only(bottom: 10, top: 10),
                                child:  Text("SALVA",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(color: Colors.white, fontSize: 18),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ))
              ],
            ),
          ),
        ) : const SizedBox.shrink()
      );
  }

  void addNewProduct() {
    print(_controllerPrice.value.text);
    print(int.parse(_controllerQuantity.value.text));
    if (selectedOptionCategory != null&&selectedOptionBrand!=null&&selectedOptionType!=null&&
        _controllerNameProduct.value.text!=''&&_controllerCodeProduct.value.text!=''&&
        _controllerDescrizione.value.text!=''&&_controllerPrice.value.text!=''&&
        _controllerQuantity.value.text!=''&&_controllerNameImage.value.text!='') {
      Product p = Product(
          nome: _controllerNameProduct.value.text,
          codice: _controllerCodeProduct.value.text,
          descrizione: _controllerDescrizione.value.text,
          categoria: selectedOptionCategory!,
          tipo: selectedOptionType!,
          marca: selectedOptionBrand!,
          prezzo: double.parse(_controllerPrice.value.text),
          quantita: int.parse(_controllerQuantity.value.text),
          immagine: _controllerNameImage.value.text);
      Model.sharedInstance.addProduct(p).then((value) {
        if(value){
          showAlertDialog("Il prodotto é stato inserito correttamente");

        }else{
          showAlertDialog("Mi dispiace. Qualcosa  andato storto.");
        }
      });
    }else{
      showAlertDialog("I campi inseriti non sono corretti");
    }
  }


  void showAlertDialog(String text){
    showDialog(
        context: context,
        builder: (BuildContext context){
          return AlertDialog(
            title: const Text("ATTENZIONE", style: TextStyle(
                fontWeight: FontWeight.bold
            ),),
            content: Text(text),
            actions: [
              TextButton(
                onPressed: () {
                  // Chiudi il dialog
                  Navigator.of(context).pop();
                },
                child: const Text('OK'),
              ),
            ],

          );
        }
    );
  }
}
