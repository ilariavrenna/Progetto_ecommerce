import 'package:app/model/Model.dart';
import 'package:app/model/support/enum/LogInResult.dart';
import 'package:app/pages/MyHomePage.dart';
import 'package:app/provider/BadgeNotifier.dart';
import 'package:app/provider/CartNotifier.dart';
import 'package:app/provider/UserNotifier.dart';
import 'package:app/widget/FormEmail.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../model/objects/User.dart';
import '../widget/FormPassword.dart';

class Login extends StatefulWidget{

  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();

}

class _LoginState extends State<Login>{
  final double _size=500;
  bool _isVisible= false;
  late TextEditingController _controllerEmail;
  late TextEditingController _controllerPsw;
  late UserNotifier userNotifier;
  late BadgeNotifier badgeNotifier;
  late CartNotifier cartNotifier;



  @override
  void initState(){
    super.initState();
    _controllerEmail= TextEditingController();
    _controllerPsw= TextEditingController();
  }

  @override
  void dispose(){
    _controllerEmail.dispose();
    _controllerPsw.dispose();
    super.dispose();
  }


  @override
  Widget build(BuildContext context) {
    userNotifier= context.watch<UserNotifier>();
    badgeNotifier= context.watch<BadgeNotifier>();
    cartNotifier= context.watch<CartNotifier>();
    return  Center(
      child:   Stack(
        alignment: AlignmentDirectional.center,
        children: [
          Padding(
          padding: const EdgeInsets.symmetric(vertical: 150, horizontal: 200),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.only(bottom: 30),
                child: SizedBox(
                     width: _size,
                     child: FormEmail(controllerEmail: _controllerEmail),
                   ),
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 50),
                child: SizedBox(
                  width: _size,
                  child: FormPassword(controllerPsw: _controllerPsw, label: "Password", callback: null,),
                ),
              ),
              SizedBox(
                width: _size,
                child: ElevatedButton(
                  onPressed: ( ) async{
                     await login(_controllerEmail.value.text,
                            _controllerPsw.value.text);
                     BuildContext currentContext = context;
                     if (userNotifier.logged&&userNotifier.role=='buyer') {
                       var snackBar =   SnackBar(
                         action: SnackBarAction(label: "Chiudi",
                             onPressed: () {
                               ScaffoldMessenger.of(context).hideCurrentSnackBar();
                             }),
                         content: const Text('Login effettuato con successo.'),
                         dismissDirection: DismissDirection.up,
                         behavior: SnackBarBehavior.floating,
                         elevation: 15.0,
                         backgroundColor: Colors.green,
                         duration: const Duration(seconds: 10),
                         padding: const EdgeInsets.all(10),
                       );
                       ScaffoldMessenger.of(context).showSnackBar(snackBar);
                       countProductInCart();
                       Navigator.pushAndRemoveUntil(currentContext, MaterialPageRoute(
                           builder: (context) => const MyHomePage()), (
                           route) => false);
                     }else {
                        var snackBar =   SnackBar(
                          action: SnackBarAction(label: "Chiudi",
                              onPressed: () {
                            ScaffoldMessenger.of(context).hideCurrentSnackBar();
                          }),
                         content: const Text('Credenziali errate. Riprova.'),
                         dismissDirection: DismissDirection.up,
                         behavior: SnackBarBehavior.floating,
                         elevation: 15.0,
                         backgroundColor: Colors.red,
                         duration: const Duration(seconds: 10),
                         padding: const EdgeInsets.all(10),
                       );
                       ScaffoldMessenger.of(context).showSnackBar(snackBar);

                     }
                  },
                  style: const ButtonStyle(
                    backgroundColor: MaterialStatePropertyAll(Colors.black),
                    shape: MaterialStatePropertyAll(RoundedRectangleBorder()),
                    overlayColor: MaterialStatePropertyAll(Colors.black)

                  ),
                    child:  const Padding(
                      padding:  EdgeInsets.only(bottom: 10, top: 10),
                      child:  Text("ENTRA NEL MIO ACCOUNT",
                          textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white, fontSize: 18),
                        ),
                    ),
                ),
              )
               ],
            ),
          ),
          Visibility(
              visible: _isVisible,
              child: const SizedBox(width:100, height: 100, child: const CircularProgressIndicator()))
        ]
      )
    );
  }


  Future<void> login(String email, String password) async {
     setState(() {
       _isVisible = !_isVisible;
     });
     LogInResult logInResult = await Model.sharedInstance.login(
         email, password);
     if (logInResult == LogInResult.logged){
       User u= await Model.sharedInstance.getUtente(cartNotifier.productInCart);
       userNotifier.login(user: u, 'buyer');
     //  cartNotifier.removeAllProduct();
     }
     setState(() {
       _isVisible = !_isVisible;
     });
   }

   void countProductInCart(){
      Model.sharedInstance.getQuantityProductInCart().then((result) {
        badgeNotifier.setValue(result);
      });
   }


}