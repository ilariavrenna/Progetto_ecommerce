import 'package:app/Icons/trash_icons.dart';
import 'package:app/model/objects/ProductInCart.dart';
import 'package:app/model/objects/ProductInPurchase.dart';
import 'package:app/model/objects/Purchase.dart';
import 'package:app/model/support/Constants.dart';
import 'package:app/model/support/enum/PurchaseResult.dart';
import 'package:app/model/support/extensions/StringCapitalization.dart';
import 'package:app/provider/BadgeNotifier.dart';
import 'package:app/provider/CartNotifier.dart';
import 'package:app/provider/UserNotifier.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../model/Model.dart';
import '../model/objects/User.dart';
import '../widget/ButtonMenu.dart';
import '../widget/ContainerMenu.dart';
import '../widget/Header.dart';


class Cart extends StatefulWidget {
  const Cart({super.key});

  @override
  State<Cart> createState() => _CartState();
}

class _CartState extends State<Cart> {
  bool _loadingData=false, _isFirstTime= false;
  late BadgeNotifier _badgeNotifier;
  late UserNotifier _userNotifier;
  late CartNotifier _cartNotifier;

  @override
  void initState(){
    super.initState();
  }


  @override
  Widget build(BuildContext context) {
    double size= MediaQuery.of(context).size.width;
    _badgeNotifier= context.watch<BadgeNotifier>();
    _userNotifier= context.watch<UserNotifier>();
    _cartNotifier= context.watch<CartNotifier>();
    return  Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        toolbarHeight: 20,
        automaticallyImplyLeading: false,
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Header(size: size),
            Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  for(String i in Constants.MENU)
              Padding(
                  padding: const EdgeInsets.only(left: 10.0, right: 10),
                  child: ButtonMenu(nameButton: i)
              ),
            ]
        ),
            Stack(
              children: [
               /*** userNotifier.logged? userCart() : infoWidget(Constants.MESSAGE_PRODUCT_CART_LOGIN), ***/
                userCart(),
                ContainerMenu(size: size),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget infoWidget(String message){
    return  Center(
      heightFactor: 15,
      child: Text(
        message,
        style: const TextStyle(
          fontWeight: FontWeight.w500,
          fontSize: 16,
        ),
      ),
    );
  }

  Widget userCart () {
    if(_userNotifier.logged && !_isFirstTime&& _userNotifier.role=='buyer') {
      _isFirstTime=true;
      _updateData();
    }
    return _loadingData?
    const SizedBox.shrink()   : listProductInCart();
  }


  Future<void> _updateData({String? typeCall, String? codeProduct}) async {
    setState(() {
      _loadingData=true;
    });
    switch(typeCall){
      case "increase":
        _cartNotifier.addList(await Model.sharedInstance.increaseProductInCart(codeProduct!));
        break;
      case "decrease":
        _cartNotifier.addList(await Model.sharedInstance.decreaseProductInCart(codeProduct!));
        break;
      case "delete":
        _cartNotifier.addList( await Model.sharedInstance.deleteProductInCart(codeProduct!));
        break;
      case "deleteAll":
        _cartNotifier.addList( await Model.sharedInstance.deleteAllProductInCart());
        break;
      default:
        _cartNotifier.addList(await Model.sharedInstance.getCart());
        break;
    }
    setState(() {
      _badgeNotifier.setValue(countProductInCart());
      _loadingData=false;
    });
  }


  int countProductInCart(){
    int value=0;
    for(ProductInCart pc in _cartNotifier.productInCart){
      value+= pc.quantity;
    }
    return value;
  }

  double _countPrice(){
    double tot=0;
    for(ProductInCart pc in _cartNotifier.productInCart ){
      tot+=pc.product.prezzo * pc.quantity;
    }
    return tot;
  }

  Widget listProductInCart(){
    return  Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 150, bottom:30 , top:50),
          child:  Text("Prodotti nel tuo Carrello: ${_badgeNotifier!.value} ",
            textAlign: TextAlign.start,
            style: const TextStyle(
                fontSize: 30,
                fontWeight: FontWeight.w500
            ),),
        ),
        Visibility( visible: _cartNotifier.productInCart.isEmpty,  child: infoWidget(Constants.MESSAGE_CART_EMPTY)),
       for(ProductInCart pc in _cartNotifier.productInCart )
          ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 170, vertical: 20),
            leading: Image.network(
              "${Constants.PATH_IMAGES}${pc.product.immagine}",
              width: 100,
              height: 100,
            ),
            title: Text(pc.product.nome,
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),),
            subtitle: Text(pc.product.marca.capitalizeAll, style: const TextStyle(fontWeight: FontWeight.w600),),
            trailing: SizedBox(
              width: pc.quantity>pc.product.quantita || pc.product.quantita<=0? 400: 300,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(
                    child: Row(
                      children: [
                         IconButton(
                           icon: const Icon(Icons.add, size: 12),
                           onPressed: pc.quantity>= pc.product.quantita? null: () {
                             //Chiamo il servizio rest per incrementare la quantità del prodotto
                             if(_userNotifier.logged&&_userNotifier.role=='buyer') {
                               _updateData(
                                  typeCall: "increase", codeProduct: pc.product.codice);
                             }else{
                               _cartNotifier.increaseProduct(pc);
                               _badgeNotifier.add();
                             }
                           },
                         ),
                        Text("${pc.quantity}", style: const TextStyle(fontSize: 14),),
                        IconButton(
                          alignment: Alignment.topCenter,
                          icon: const Icon(Icons.minimize, size:14),
                          onPressed: () {
                            print(pc.product.codice);
                            if(_userNotifier.logged&&_userNotifier=='buyer') {
                              //Chiamo il servizio rest per minimizzare la quantità di elementi
                              print(pc.product.codice);
                              _updateData(typeCall: "decrease",
                                  codeProduct: pc.product.codice);
                            }else{
                              _cartNotifier.decreaseProduct(pc);
                              _badgeNotifier.minimize();
                            }

                          }, ),
                      ],
                    ),
                  ),
                   Padding(
                    padding:  const EdgeInsets.only(bottom: 8.0, top: 8.0, left: 20.0, right: 20.0),
                    child:  Container(
                      height: 30,
                      width: 50,
                      alignment: AlignmentDirectional.center,
                      child: Text("${pc.product.prezzo.toStringAsFixed(2)}€",
                        style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w700

                        ),),
                    ),
                  ),
                  Padding(
                      padding: const EdgeInsets.only(bottom: 8.0, top: 8.0, left: 20.0, right: 20.0),
                      child: Container(
                        height: 30,
                        width: 30,
                        alignment: AlignmentDirectional.center,
                        child: IconButton(icon: const Icon(Trash.trashcan, size: 16,),
                          onPressed: () {
                            if(_userNotifier.logged&&_userNotifier.role=='buyer') {
                              _updateData(
                                  typeCall: "delete", codeProduct: pc.product.codice);
                            }else{
                              _cartNotifier.removeAllQuantityProduct(pc);
                              _badgeNotifier.removeAll(pc.quantity);
                            }
                          },),
                      )
                  ),
                  Visibility(
                      visible: pc.quantity> pc.product.quantita || pc.product.quantita<=0,
                      child: Text(
                          pc.quantity> pc.product.quantita? "Quantità non disponibile" : "Prodotto non disponibile",
                        style: const TextStyle(
                          color: Colors.red,
                          fontWeight: FontWeight.w600
                        ),
                      ))
                ],
              ),
            ),
            onTap: ( ){
              Navigator.pushNamed(
                  context, '/product', arguments: pc.product);            },
          ),
        Align(
          alignment: Alignment.centerRight,
          child: Visibility(
            visible: _cartNotifier.productInCart.isNotEmpty,
            child: Padding(
              padding: const EdgeInsets.only(right: 250, bottom: 20, top: 20),
              child: SizedBox(
                width: 400,
                child: Column(
                  children: [
                    Container(
                      width: 400,
                      height: 0.75,
                      color: Colors.black,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 20, bottom: 20),
                      child:  Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text("Totale",
                            textAlign: TextAlign.end,
                            style: TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.w700
                            ),),
                          Text( "${_countPrice().toStringAsFixed(2)}€",
                            style: const TextStyle(
                                fontSize: 30,
                                fontWeight: FontWeight.w500
                            ),),

                        ],
                      ),
                    ),
                    SizedBox(
                      width: 400,
                      height: 40,
                      child: ElevatedButton(
                        onPressed: (){
                          if(_userNotifier.logged&&_userNotifier.role=='buyer') {
                            //Completa acquisto
                            completaAcquisto();
                          }else{
                            showDialog(
                                context: context,
                                builder: (BuildContext context){
                                  return AlertDialog(
                                    title: const Text("ATTENZIONE", style: TextStyle(
                                        fontWeight: FontWeight.bold
                                    ),),
                                    content: const Text(Constants.MESSAGE_PURCHASE_LOGIN),
                                    actions: [
                                      TextButton(
                                        onPressed: () {
                                          // Chiudi il dialog
                                          Navigator.of(context).pop();
                                        },
                                        child: const Text('OK'),
                                      ),
                                    ],

                                  );
                                }
                            );
                          }
                        },
                        style:  ButtonStyle(
                            backgroundColor:  MaterialStateProperty.resolveWith<Color>((Set<MaterialState> states) {
                                  if(states.contains(MaterialState.pressed)){
                                    return Colors.green;
                                  }
                                  return Colors.black;
                              }
                            ),
                            shape: const MaterialStatePropertyAll(RoundedRectangleBorder()),
                            overlayColor:  MaterialStateProperty.resolveWith<Color>((Set<MaterialState> states) {
                                  if(states.contains(MaterialState.pressed)){
                                    return Colors.green;
                                  }
                                  return Colors.black;
                               }
                            )
                        ),
                        child:  const Padding(
                          padding:  EdgeInsets.only(bottom: 10, top: 10),
                          child:  Text("CONCLUDI L'ORDINE",
                            textAlign: TextAlign.center,
                            style: TextStyle(color: Colors.white, fontSize: 16),
                          ),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
        )
      ],
    );
  }



  void completaAcquisto(){
    List<ProductInPurchase> listaProdottiAcquistati=[];
    for(ProductInCart productInCart in _cartNotifier.productInCart){
      listaProdottiAcquistati.add(ProductInPurchase(prezzo: productInCart.product.prezzo, quantita: productInCart.quantity, prodotto: productInCart.product));
    }
        Purchase purchase= Purchase( utente: _userNotifier.user!, prezzo: _countPrice(), listaProdottiAcquistati: listaProdottiAcquistati);
        Model.sharedInstance.makePurchase(purchase).then((result){
          if(result["response"]==PurchaseResult.completated){
            showSnackBar(Constants.MESSAGE_PURCHASE_OK, Colors.green);
            //_updateData("deleteAll");
            //_loadData();
            _updateData();
          }else if(result["response"]==PurchaseResult.notFoundQuantity){
            setState(() {
              _cartNotifier.addList(result["result"]);
              Model.sharedInstance.getQuantityProductInCart().then((result) {
                _badgeNotifier.setValue(result);
              });
            });
            showSnackBar(Constants.MESSAGE_CART_UPDATE, Colors.red);
          }else{
            showSnackBar(Constants.MESSAGE_PURCHASE_NO, Colors.red);
          }
        });
  }

  void showSnackBar(String text, Color color){
    var snackBar =   SnackBar(
      action: SnackBarAction(label: "Chiudi",
          onPressed: () {
            ScaffoldMessenger.of(context).hideCurrentSnackBar();
          }),
      content: Text(text),
      dismissDirection: DismissDirection.up,
      behavior: SnackBarBehavior.floating,
      elevation: 15.0,
      backgroundColor: color,
      duration: const Duration(seconds: 10),
      padding: const EdgeInsets.all(10),
    );
    ScaffoldMessenger.of(context).showSnackBar(snackBar);

  }
}
