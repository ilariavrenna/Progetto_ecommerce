import 'dart:html';

import 'package:app/model/Model.dart';
import 'package:app/model/objects/Product.dart';
import 'package:app/model/support/extensions/StringCapitalization.dart';
import 'package:app/provider/UserNotifier.dart';
import 'package:app/widget/CircularActionButton.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../Icons/icons_arrows_icons.dart';
import '../Icons/my_flutter_app_icons.dart';
import '../model/support/Constants.dart';
import '../model/support/enum/LogInResult.dart';
import '../widget/FormEmail.dart';
import '../widget/FormPassword.dart';

class Admin extends StatefulWidget {
  const Admin({super.key});

  @override
  State<Admin> createState() => _AdminState();
}

class _AdminState extends State<Admin> {
  final double _size=500;
  int _page=0;
  bool _lastPage=false;
  List<Product> listProduct=[];
  late TextEditingController _controllerEmail;
  late TextEditingController _controllerPsw;
  bool visibilityLogin=true, visibilityApp=false;
  late double _width, _height;
  late UserNotifier _userNotifier;

  Function function= () {
    //Navigo alla pagina per aggiungere un nuovo prodotto
  };

  @override
  void initState(){
    super.initState();
    _controllerEmail= TextEditingController();
    _controllerPsw= TextEditingController();
  }

  @override
  void dispose(){
    _controllerEmail.dispose();
    _controllerPsw.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    _userNotifier= context.watch<UserNotifier>();
    _width = MediaQuery.of(context).size.width;
    _height= MediaQuery.of(context).size.height;
    return  Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        toolbarHeight: 70,
        automaticallyImplyLeading: false,
        leading: Visibility(
          visible:  visibilityApp,
          child: IconButton(
            icon: const Icon(MyFlutterApp.logout_1, color: Colors.white, size: 20),
            onPressed: () {
              signOut(context);
            },
          ),
        ),
      ),
      floatingActionButton: visibilityApp? CircularActionButton(icon: const Icon(Icons.add), function: (){
        Navigator.of(context).pushNamed('/admin/add/product');
      },): null,
      body:
      _userNotifier.logged&&_userNotifier.role=='admin'?
          admin() : login(),
      /*Stack(
        children: [
          Visibility(visible: visibilityLogin, child: login()),
          Visibility(visible: visibilityApp, child: admin())
        ],
      ) ,*/
    );
  }



  Widget login(){
    return  Padding(
      padding: const EdgeInsets.symmetric(vertical: 150.0),
      child: Center(
        child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.only(bottom: 30),
                child: SizedBox(
                  width: _size,
                  child: FormEmail(controllerEmail: _controllerEmail),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 50),
                child: SizedBox(
                  width: _size,
                  child: FormPassword(controllerPsw: _controllerPsw, label: "Password", callback: null,),
                ),
              ),
              SizedBox(
                width: _size,
                child: ElevatedButton(
                  onPressed: ( ){
                    loginAdmin(_controllerEmail.value.text, _controllerPsw.value.text);
                    _controllerPsw.text='';
                    _controllerEmail.text='';
                  },
                  style: const ButtonStyle(
                      backgroundColor: MaterialStatePropertyAll(Colors.black),
                      shape: MaterialStatePropertyAll(RoundedRectangleBorder()),
                      overlayColor: MaterialStatePropertyAll(Colors.black)

                  ),
                  child:  const Padding(
                    padding:  EdgeInsets.only(bottom: 10, top: 10),
                    child:  Text("ACCEDI",
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white, fontSize: 18),
                    ),
                  ),
                ),
              )
            ],
        ),
      ),
    );
  }


  void loginAdmin(String email, String password){
      Model.sharedInstance.login(email, password).then( (result) async {
      if (result == LogInResult.logged){
        _userNotifier.login('admin');
        listProduct= await Model.sharedInstance.getAllProduct(pageNumber: _page, pageSize: Constants.SIZE_PAGE_ADMIN);
        if(listProduct.length<Constants.SIZE_PAGE_ADMIN) {
          _lastPage=true;
        }else{
          _page++;
        }
        setState(() {
          visibilityLogin=false;
          visibilityApp=true;
          _controllerPsw.text='';
          _controllerEmail.text='';
        });
      }else {
          var snackBar =   SnackBar(
              action: SnackBarAction(label: "Chiudi",
              onPressed: () {
              ScaffoldMessenger.of(context).hideCurrentSnackBar();
              }),
              content: const Text('Credenziali errate. Riprova.'),
              dismissDirection: DismissDirection.up,
              behavior: SnackBarBehavior.floating,
              elevation: 15.0,
              backgroundColor: Colors.red,
              duration: const Duration(seconds: 10),
              padding: const EdgeInsets.all(10),
          );
          ScaffoldMessenger.of(context).showSnackBar(snackBar);
    }
  }
      );

  }

  Widget admin(){
    return Padding(
      padding: const EdgeInsets.only(top: 20),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          SizedBox(
            width: _width*0.9,
            height: _height*0.8,
            child: Column(
              children: [
                for(int index=0; index<listProduct.length; index++)
                  ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 50, vertical: 20),
                    leading: Image.network(
                      "${Constants.PATH_IMAGES}${listProduct[index].immagine}",
                      width: 100,
                      height: 100,
                    ),
                    title: Text(listProduct[index].nome,
                      style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),),
                    subtitle: Text(listProduct[index].marca.capitalizeAll, style: const TextStyle(fontWeight: FontWeight.w600),),
                    onTap: (){
                      Navigator.pushNamed(context, '/admin/info/product', arguments: listProduct[index]);
                    },
                  ),
          ],)),
          Align(
            alignment: Alignment.bottomCenter,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                IconButton(onPressed: _page>1? (){ lastPage();} : null, icon: const Icon(IconsArrows.angle_double_left)),
                IconButton(onPressed: _lastPage? null: (){nextPage();}, icon: const Icon(IconsArrows.angle_double_right))
              ],
            ),
          )
        ],
      ),
    );
  }


  void nextPage(){
    Model.sharedInstance.getAllProduct(pageNumber: _page, pageSize: Constants.SIZE_PAGE_ADMIN).then((value) {
     setState(() {
       listProduct=value;
       if(value.length<Constants.SIZE_PAGE_ADMIN){
         _lastPage=!_lastPage;
       }else{
         _page++;
       }
     });
    });
  }

  void lastPage(){
    Model.sharedInstance.getAllProduct(pageNumber: _page-1, pageSize: Constants.SIZE_PAGE_ADMIN).then((value) {
      setState(() {
        listProduct=value;
        if(_page!=0){
          _page--;
        }
        if(_lastPage) {
          _lastPage = !_lastPage;
        }
      });
    });
  }

  void signOut(BuildContext context){
    Model.sharedInstance.logout().then((result) {
      if(result){
        setState(() {
          _userNotifier.logout();
          visibilityApp=false;
          visibilityLogin=true;
        });
      }
    });
  }




}
