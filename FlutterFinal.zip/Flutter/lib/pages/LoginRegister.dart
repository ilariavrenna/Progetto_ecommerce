import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'Login.dart';
import 'Register.dart';

class LoginRegister extends StatefulWidget{

  const LoginRegister({super.key});

  @override
  State<LoginRegister> createState() => _LoginRegisterState();

}

class _LoginRegisterState extends State<LoginRegister>{

  final int _length=2;

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
        length: _length,
        child: Scaffold(
          appBar: AppBar(
            automaticallyImplyLeading: false,
            elevation: 10.0,
            backgroundColor: Theme.of(context).colorScheme.inversePrimary,
            bottom: const TabBar(
              indicatorSize: TabBarIndicatorSize.tab,
              labelStyle: TextStyle(
                fontSize: 20,
                fontFamily: 'allright',
                fontWeight: FontWeight.bold
              ),
               indicatorWeight: 1.0,
                tabs: [
                  Tab(
                    text: "ACCEDI",
                  ),
                  Tab(
                    text: "ISCRIVITI",

                  )
                ]),
          ) ,
          body: const TabBarView(
            children: [
              Login(),
              Register()
            ],
          ),
        ));


  }
}
