import 'package:app/model/support/Constants.dart';
import 'package:app/model/support/extensions/StringCapitalization.dart';
import 'package:app/widget/ButtonMenu.dart';
import 'package:app/widget/CircularActionButton.dart';
import 'package:app/widget/Header.dart';
import 'package:flutter/material.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import '../model/Model.dart';
import '../model/objects/Product.dart';
import '../widget/ContainerMenu.dart';

class MyHomePage extends StatefulWidget {

  const MyHomePage({super.key});


  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _crossAxisCount = 3;
  late ScrollController _scrollController;
  final PagingController<int, Product> _pagingController = PagingController(firstPageKey: 0);
  late double _size;
  int _page =0;
  bool _isLastPage=false, _isFabVisible=false;

  @override
  void initState() {
    super.initState();
    _scrollController = ScrollController();
    _scrollController.addListener(_scrollListener);
    _loadData();
  }

  void _scrollListener(){
    if(_scrollController.position.pixels== _scrollController.position.maxScrollExtent && !_isLastPage){
      _loadData();
    }
    if(_scrollController.position.pixels>200){
      setState(() {
        _isFabVisible=true;
      });
    }
    if(_scrollController.position.pixels <200){
      setState(() {
        _isFabVisible=false;
      });
    }
  }

  @override
  void dispose() {
    _scrollController.dispose();
    _pagingController.dispose();
    super.dispose();
  }


  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size.width;
    if (_size < 945) {
      _crossAxisCount= 2;
    }else{
      _crossAxisCount= 3;
    }
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        toolbarHeight: 20,
        automaticallyImplyLeading: false,
      ),
      floatingActionButton: _isFabVisible? CircularActionButton(icon: const Icon(Icons.navigation),function: ( ){
        _scrollController.animateTo(
          0, // Posizione di destinazione (in questo caso, l'inizio)
          duration: const Duration(microseconds: 30), // Durata dell'animazione
          curve: Curves.bounceIn, // Tipo di curva di animazione
        );
      },): null,
      body: Scrollbar(
        thumbVisibility: true,
        controller: _scrollController,
        child: SingleChildScrollView(
          controller: _scrollController,
          child: Column(
            children: [
              Header(size: _size),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  for(String i in Constants.MENU)
                    Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10.0),
                        child: ButtonMenu(nameButton: i)
                    ),
                ],
              ),
              Stack(
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 50),
                      child: Grid()
                    ),
                    ContainerMenu(size: _size)

                  ]
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _loadData( ) async {
    try {
      final newData = await Model.sharedInstance.getAllProduct(pageNumber: _page);

      if (newData.isEmpty) {

        _isLastPage=true;
        _pagingController.appendLastPage([]);
      } else {
        _page++;
        _pagingController.appendLastPage(newData);
        _isLastPage= newData.length < 12;
      }
    } catch (error) {
      _pagingController.error = error;
    }
  }


  Widget Grid(){
    return PagedGridView<int, Product>(
         pagingController: _pagingController,
         gridDelegate:SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: _crossAxisCount,
            mainAxisSpacing: 8.0,
            crossAxisSpacing: 8.0
        ),
        shrinkWrap: true,
        showNewPageProgressIndicatorAsGridChild: false,
        builderDelegate: PagedChildBuilderDelegate<Product>(
          firstPageProgressIndicatorBuilder: (context){
            return const Padding(
              padding:  EdgeInsets.symmetric(vertical: 150),
              child:  Center(child: SizedBox(width: 100, height: 100 , child: CircularProgressIndicator(),),),
            );
          },
          noItemsFoundIndicatorBuilder: (context){
            return const Text(Constants.MESSAGE_NOT_FOUND_PRODUCT, style: TextStyle( color: Colors.black87, fontSize: 16));
          },
          itemBuilder: (context, product, index){
            return SizedBox(
              height: _size * 0.8,
              width: _size * 0.7,
              child: InkWell(
                hoverColor: Colors.transparent,
                onTap: () {
                  Navigator.pushNamed(
                      context, '/product', arguments: product);
                },
                child: Card(
                  color: Colors.white70,
                  elevation: 0,
                  child: Column(
                    children: [
                      Image.network(
                        "${Constants.PATH_IMAGES}${product.immagine}",
                        width: _size*0.18,
                        height: _size*0.18,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 15, bottom: 10),
                        child: Text(
                          product.nome,
                          textAlign: TextAlign.left,
                          style:  TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: _size<1050 ? 10 : 14,
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: Text(
                          product.marca.capitalizeAll,
                          style:  TextStyle(
                            fontSize: _size<1050 ? 9 : 13,
                          ),
                        ),
                      ),
                      Text(
                        "${product.prezzo.toStringAsFixed(2)}€",
                        style:  TextStyle(
                            fontSize: _size<1050 ? 10 : 14,
                            fontWeight: FontWeight.bold
                        ),
                      )
                    ],
                  ),
                ),
              ),
            );
          }
        ));
  }


}


