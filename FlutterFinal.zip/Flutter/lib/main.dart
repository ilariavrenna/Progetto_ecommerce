import 'dart:io';

import 'package:app/provider/BadgeNotifier.dart';
import 'package:app/provider/CartNotifier.dart';
import 'package:app/provider/UserNotifier.dart';
import 'package:app/provider/VisibilityNotifier.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'App.dart';



void main() {

  runApp(
    MultiProvider(providers: [
      ChangeNotifierProvider(create: (context) => VisibilityNotifier()),
      ChangeNotifierProvider(create: (context) => BadgeNotifier()),
      ChangeNotifierProvider(create: (context) => UserNotifier()),
      ChangeNotifierProvider(create: (context) => CartNotifier())
    ],
      child: const App(),
    ),
  );
}




