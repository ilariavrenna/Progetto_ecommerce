import 'package:app/pages/Account.dart';
import 'package:app/pages/AddNewProduct.dart';
import 'package:app/pages/Admin.dart';
import 'package:app/pages/Cart.dart';
import 'package:app/pages/InfoProduct.dart';
import 'package:app/pages/LoginRegister.dart';
import 'package:app/pages/MyHomePage.dart';
import 'package:app/pages/ProductDescription.dart';
import 'package:app/pages/SearchProduct.dart';
import 'package:flutter/material.dart';

class App extends StatelessWidget {
  const App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primaryColor: Colors.deepOrange,
        useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepOrange).copyWith(background: Colors.white)

      ),
      home: const MyHomePage(),
      routes: {
        '/search' : (context) => const SearchProduct(),
        '/account' : (context) => const LoginRegister(),
        '/cart' : (context) =>  const Cart(),
        '/product' : (context) => const ProductDescription(),
        '/profile' : (context) => const Account(),
        '': (context) => const MyHomePage(),
        '/admin': (context) => const Admin(),
        '/admin/info/product': (context) => const InfoProduct( ),
        '/admin/add/product': (context) => const AddNewProduct( ),
      },
    );
  }
}